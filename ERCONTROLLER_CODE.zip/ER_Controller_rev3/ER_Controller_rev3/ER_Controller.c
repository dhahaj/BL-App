/*
 * ER_Controller.c
 */ 

#include <avr/io.h>
#define F_CPU 1000000UL	//  8MHz�CLK/8 = 1 MHz system clock
#include <util/delay.h>
#include <avr/pgmspace.h>
#include <avr/wdt.h>
#include <util/atomic.h>
//  #include <stdlib.h>
//  #include <stdio.h>
//  #include <string.h>
//  #include <inttypes.h>
#include <stdbool.h>

/*
OUTPUT DEFINITIONS:		*/
#define OUTPUT_PORT		PORTB	// Output port for Door1/2 and Signals1/2
#define OUTPUT_DDR		DDRB	// Data Direction Port for output
#define DR1_OUT			PORTB0	// Door 1 output pin
#define DR2_OUT			PORTB1	// Door 2 output pin
#define SIG1_OUT_PIN	PORTB2	// Signal 1 output pin
#define SIG2_OUT_PIN	PORTB3	// Signal 2 output pin

/*						
INPUT DEFINITIONS:		*/
#define INPUT_PIN			PIND	// Input Port for Door 1 & Door 2
#define INPUT_PORT			PORTD	// Input Port for Door 1 & Door 2
#define INPUT_DDR			DDRD	// Data Direction for Input Ports
#define MODE_PIN			PIND0	// Mode selection pin
#define TOGGLE1_PIN			PIND1	// Toggle Mode pin for Door 1
#define TOGGLE2_PIN			PIND7	// Toggle Mode pin for Door 2
#define DR1_BUTTON			PIND2	// Door 1 Input Pin
#define DR2_BUTTON			PIND3	// Door 2 Input Pin
#define ACTIVE_MODE1_PIN	PIND4	// Active Mode Pin for Door 1
#define ACTIVE_MODE2_PIN	PIND5	// Active Mode Pin for Door 2
#define DS_PORT				PORTC	// Digital Switch Input Port
#define DS_DDR				DDRC	// Data Direction for DS_PORT
#define DS1_PIN				PORTC0	// DS1 Control Output Pin
#define DS2_PIN				PORTC1	// DS2 Control Output Pin

/*
CONSTANT DEFINITIONS:	*/
#define DIFF_DELAY		500UL	// Differential Delay Time between door retractions(ms)
#define SIG_DELAY		600UL	// Signal Delay Time before activating door signals(ms)
#define DEBOUNCE_TIME	255		// Switch Debounce Time
#define DEPENDENT		0x1		// Operating Mode Types
#define INDEPENDENT		0x0
#define ACTIVE_HIGH		0x1		// Output Mode Types
#define ACTIVE_LOW		0x0

#define BIT(x) (0x01 << (x))
#ifndef boolean
typedef uint8_t boolean;
#endif
// #define true			(0==0)	// Boolean Types
// #define false			(0!=0)

// Global Variables for the various configurations
typedef struct {
	volatile boolean toggled_mode;
	volatile boolean isToggled;
	volatile boolean isActive;
	volatile uint8_t output_mode;
} door;

door dr1 = {false, false, false, ACTIVE_HIGH};
door dr2 = {false, false, false, ACTIVE_HIGH};

typedef struct inputs {
	boolean mode;
	const uint8_t inputPinMask;
} Inputs;

Inputs inputs = {DEPENDENT, (BIT(MODE_PIN) | BIT(TOGGLE1_PIN) | BIT(TOGGLE2_PIN) | BIT(DR1_BUTTON) | BIT(DR2_BUTTON) | BIT(ACTIVE_MODE1_PIN) | BIT(ACTIVE_MODE2_PIN)) };

volatile uint8_t inputReg = 0x0;


#include "timers.h"

// Array holding the 4-bit timing selection values (in seconds)
const uint8_t PROGMEM timing_values_PGM[] = {
	1,	// 0
	2,	// 1
	5,	// 2
	10,	// 3
	15,	// 4
	20, // 5
	25,	// 6
	30,	// 7
	35,	// 8
	40, // 9
	45, // A
	50,	// B
	55,	// C
	60, // D
	90,	// E
	120,// F
};

#define getTimingValue(P) ( pgm_read_byte( timing_values_PGM + (P) ) )

void doorPinWrite(uint8_t doorPin, boolean active)
{
	byte mode;
	if(doorPin==DR1_OUT){
		if(active==true)
			mode = bit_get((dr1.isActive), BIT(0));
		else
			mode = !bit_get(dr1.output_mode, BIT(0));
		bit_write( mode, OUTPUT_PORT, BIT(DR1_OUT) );
	} else {
		if(active==true)
			mode = bit_get(dr2.output_mode, BIT(0));
		else
			mode = !bit_get(dr2.output_mode, BIT(0));
		bit_write( mode, OUTPUT_PORT, BIT(DR2_OUT));
	}
	return;
}

uint8_t button_is_pressed(uint8_t PIN, uint8_t BIT)
{
	/* the button is pressed when BUTTON_BIT is clear */
	if (bit_is_clear(PIN, BIT))	{
		_delay_ms(DEBOUNCE_TIME);
		if (bit_is_clear(PIN, BIT)) return 1;
	}
	return 0;
}

unsigned long getHoldTime(uint8_t door)
{
	uint8_t time;
	if(door<2) {
		// Read DS1: set PC0 high, PC1 Low
		sbi(DS_PORT, DS1_PIN);
		loop_until_bit_is_set(DS_PORT, DS1_PIN);
		cbi(DS_PORT, DS2_PIN);		
		loop_until_bit_is_clear(DS_PORT, DS2_PIN);
	} else {
		// Read DS2: set PC0 Low, PC1 high
		sbi(DS_PORT, DS2_PIN);
		loop_until_bit_is_set(DS_PORT, DS2_PIN);
		cbi(DS_PORT, DS1_PIN);
		loop_until_bit_is_clear(DS_PORT, DS1_PIN);
	}
	uint8_t DSx_value = (PINC & 0x3c)>>2;
	time = (unsigned long)(getTimingValue(DSx_value));
	return time;
}

void dependentRetract(void)
{
//	In toggle mode?
	if(dr1.toggled_mode==true) {
		if(dr1.isToggled==true) /*Outputs currently toggled, so toggle them off*/ {
			doorPinWrite(DR1_OUT,false); // Door 1 off
			doorPinWrite(DR2_OUT,false); // Door 2 off
			cbi(OUTPUT_PORT, SIG1_OUT_PIN);	// Turn off door signal outputs
			cbi(OUTPUT_PORT, SIG2_OUT_PIN);
			dr1.isToggled = false;
			dr2.isToggled = false;
		} 	else	/* Outputs not toggled, so toggle them now */ {
			ATOMIC_BLOCK(ATOMIC_RESTORESTATE){
				doorPinWrite(DR1_OUT,true); // Door 1 Active
				dr1.isToggled = true;
				_delay_ms(DIFF_DELAY); // Differential Delay
				wdt_reset(); // Reset the watchdog timer	
				doorPinWrite(DR2_OUT,true); // Door 2 Active
				dr2.isToggled = true;
				_delay_ms(SIG_DELAY);	// Door Signal Delay
				sbi(OUTPUT_PORT, SIG1_OUT_PIN);	// Turn on door signal outputs
				sbi(OUTPUT_PORT, SIG2_OUT_PIN);
			}			
			while( bit_is_clear(INPUT_PIN, DR1_BUTTON) || bit_is_clear(INPUT_PIN, DR2_BUTTON) ) // Maintain while buttons are held
				{ wdt_reset(); /* Reset the watchdog timer */ }
		}
	} else /*Not in toggle mode*/ {
		ATOMIC_BLOCK(ATOMIC_RESTORESTATE){
			//retracting = true;
			doorPinWrite(DR1_OUT,true); // Door 1 Active
			_delay_ms(DIFF_DELAY); // Differential Delay
			doorPinWrite(DR2_OUT,true); // Door 2 Active
			_delay_ms(SIG_DELAY);	// Door Signal Delay
			sbi(OUTPUT_PORT, SIG1_OUT_PIN);	// Activate door signal outputs
			sbi(OUTPUT_PORT, SIG2_OUT_PIN);
		}
		door1_timer(true); // Initialize the Door 1 timer
		while( door1_timer(0) <= getHoldTime(1)*1e3 ) // Hold Time Delay, value set from DS1
		{
			wdt_reset(); // Reset the watchdog timer
			if( bit_is_clear(INPUT_PIN, DR1_BUTTON) || bit_is_clear(INPUT_PIN, DR2_BUTTON) )	// Maintain active outputs when button is held
				door1_timer(true); // reset the timer 
			if(inputs.mode==INDEPENDENT) // If mode changed, break loop
				break;
		}
		doorPinWrite(DR1_OUT,false); // Door outputs off
		doorPinWrite(DR2_OUT,false);
		cbi(OUTPUT_PORT, SIG1_OUT_PIN);	// Deactivate door signal outputs
		cbi(OUTPUT_PORT, SIG2_OUT_PIN);
		//retracting = false;
	}
}

void activateDoor1(boolean activate){
	if(activate==false){
		doorPinWrite(DR1_OUT,false);
		cbi(OUTPUT_PORT,SIG1_OUT_PIN);
	} else {
// 		ATOMIC_BLOCK(ATOMIC_RESTORESTATE) // Ensure the following code completes before running an interrupt
// 		{
			doorPinWrite(DR1_OUT,true);
			_delay_ms(SIG_DELAY);
			sbi(OUTPUT_PORT,SIG1_OUT_PIN);
//		}
	}
	wdt_reset(); // Reset the watchdog timer
}

void activateDoor2(boolean activate){
	if(activate==false){
		doorPinWrite(DR2_OUT,false);
		cbi(OUTPUT_PORT,SIG2_OUT_PIN);
	} else {
// 		ATOMIC_BLOCK(ATOMIC_RESTORESTATE) // Ensure the following code completes before running an interrupt
// 		{
			doorPinWrite(DR2_OUT,true);
			_delay_ms(SIG_DELAY);
			sbi(OUTPUT_PORT,SIG2_OUT_PIN);
//		}
	}
	wdt_reset(); // Reset the watchdog timer
}

volatile uint8_t time1,time2;

/*
Initialize the global variables */
void getInputs(void)
{
	inputReg = INPUT_PIN & inputs.inputPinMask;
	
	if( bit_is_set(inputReg,0) ) { inputs.mode = DEPENDENT; }
	else { inputs.mode = INDEPENDENT; }
	
	if( bit_is_set(inputReg,TOGGLE1_PIN) ) { dr1.toggled_mode = false; }
	else { dr1.toggled_mode = true; }
	
	if( bit_is_set(inputReg,ACTIVE_MODE1_PIN) ) { dr1.output_mode = ACTIVE_HIGH; }
	else { dr1.output_mode = ACTIVE_LOW; }
	
	if( bit_is_set(inputReg,ACTIVE_MODE2_PIN) ) { dr2.output_mode = ACTIVE_HIGH; }
	else { dr2.output_mode = ACTIVE_LOW; }
		
	if( bit_is_set(inputReg,ACTIVE_MODE2_PIN) ) { dr2.output_mode = ACTIVE_HIGH; }
	else { dr2.output_mode = ACTIVE_LOW; }
		
	if( bit_is_set(inputReg,TOGGLE2_PIN) ) { dr2.toggled_mode = false; }
	else { dr2.toggled_mode = true; }
	
	uint16_t *t1;
	
//	if(!dr1.isActive){
		t1 = &time1;
		ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { *t1 = getHoldTime(1); }
	//}
	//if(!dr2.isActive){		
		t1 = &time2;
		ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { *t1 = getHoldTime(2); }
//	}		
}

/*
Interrupt Handler For PCINT23:16 (PIND)
This routine changes the global variables and resynchronizes
the outputs to correspond with the changes	*/
ISR(PCINT2_vect)
{
	// The set bits in 'reg' corresponds to the changed pin inputs
	uint8_t reg = (INPUT_PIN^inputReg);
	
	if(  bit_is_set(reg, 0) ) // Operating Mode Changed
	{
		dr1.isActive = false;
		dr2.isActive = false;
		
		// Set the operating mode
		if( bit_get(INPUT_PIN, BIT(MODE_PIN) ) )
			inputs.mode = DEPENDENT;
		else
			inputs.mode = INDEPENDENT;
			
		// Change the input register value
		bit_write(inputs.mode, inputReg, BIT(0));
			
		// Turn off any active outputs for the new mode
		doorPinWrite(DR1_OUT,false);
		doorPinWrite(DR2_OUT,false);
		cbi(OUTPUT_PORT,SIG1_OUT_PIN);
		cbi(OUTPUT_PORT,SIG2_OUT_PIN);
		dr2.isToggled = false;
		dr1.isToggled = false;
		//retracting = false;
		door1_timer(false);
//		door2_timer(false);
	}
		
	if( bit_is_set(reg, 4) ) // Door 1 Active Mode Changed
	{
		// Set the Door 1 active mode
		if( bit_get(INPUT_PIN,BIT(ACTIVE_MODE1_PIN)) ) {
			dr1.output_mode = ACTIVE_HIGH;
			sbi(inputReg,ACTIVE_MODE1_PIN);
		} else {
			dr1.output_mode = ACTIVE_LOW;
			cbi(inputReg,ACTIVE_MODE1_PIN);
		}
			
		if( dr1.isActive || dr1.isToggled /*|| retracting*/) // If Door 1 is active anywhere ? Door 1 Output = Active Mode 1
			doorPinWrite(DR1_OUT,true);
		else										 // Otherwise ? Door 1 Output = !Active Mode
			doorPinWrite(DR1_OUT,false);
	}

	if( bit_is_set(reg, 5) ) // Door 2 Active Mode Changed
	{
		// Set the Door 2 active mode
		if( bit_get(INPUT_PIN,BIT(ACTIVE_MODE2_PIN)) ) {
			dr2.output_mode = ACTIVE_HIGH;
			sbi(inputReg, ACTIVE_MODE2_PIN);
		} else {
			dr2.output_mode = ACTIVE_LOW;
			cbi(inputReg, ACTIVE_MODE2_PIN);
		}
			
		if( dr2.isActive || dr2.isToggled /*|| retracting*/) // If Door 2 is active anywhere -> Door 2 Output = Active Mode 2
			doorPinWrite(DR2_OUT,true);
		else										 // Otherwise -> Door 2 Output = !Active Mode 2
			doorPinWrite(DR2_OUT,false);
	}
		
	if( bit_is_set(reg, 1) ) // Door 1 Toggle Mode Changed
	{
		// Set the door 1 toggle value
		if( bit_get(INPUT_PIN, BIT(TOGGLE1_PIN)) ) {
			dr1.toggled_mode = false;
			sbi(inputReg,TOGGLE1_PIN);
		} else {
			dr1.toggled_mode = true;
			cbi(inputReg,TOGGLE1_PIN);
		}
			
		if( dr1.isToggled && dr1.toggled_mode==false ) /* Toggle mode changed to off and output is toggled!*/
		{
			doorPinWrite(DR1_OUT,false);
			cbi(OUTPUT_PORT,SIG1_OUT_PIN);
			dr1.isToggled = false;
			if(inputs.mode==DEPENDENT){
				doorPinWrite(DR2_OUT,false);
				cbi(OUTPUT_PORT,SIG2_OUT_PIN);
				dr2.isToggled = false;
			}
		}
		bit_write( !bit_get(dr1.toggled_mode,BIT(0)), inputReg, BIT(1)); /*Change the input register value*/
	}

	if( bit_is_set(reg, 7) )// Door 2 Toggle Mode Changed
	{
		// Set the door 2 toggle value
		if( bit_get(INPUT_PIN, BIT(TOGGLE2_PIN)) ) {
			dr2.toggled_mode = false;
			sbi(inputReg,TOGGLE2_PIN);
		} else {
			dr2.toggled_mode = true;
			cbi(inputReg,TOGGLE2_PIN);
		}
			
		if( dr2.isToggled && dr2.toggled_mode==false && inputs.mode == INDEPENDENT) /*Toggle mode changed to off and output is toggled!*/
		{
			doorPinWrite(DR2_OUT,false);
			cbi(OUTPUT_PORT,SIG2_OUT_PIN);
			dr2.isToggled = false;
		}
		bit_write( !bit_get(dr2.toggled_mode,BIT(0)), inputReg, BIT(7)); /*Change the input register value*/
	}
}


volatile unsigned long timer1A_counter=0, timer1B_counter=0;

int main(void) {

//	INIT:
	wdt_reset();
	wdt_enable(WDTO_4S);					// Enable Watchdog Timer @ 2 second time-out
	TCCR0A |= BIT(CS01) | BIT(CS00);		// Initialize timer0 with a prescaler of 64	
	sbi(TIMSK0, TOIE0); 					// enable timer 0 overflow interrupt

	INPUT_PIN = 0xff;						// Enable the Input Port internal pull-ups
	INPUT_DDR = 0x00;						// Initialize Input Port as inputs
	
 	OUTPUT_DDR = 0xff;						// Output Port initialized as outputs
	DS_DDR = BIT(DS1_PIN) | BIT(DS2_PIN);	// PC0 & PC1 set as outputs for DS switches
	
	sbi(PCICR,PCIE2);
	PCMSK2 = BIT(PCINT16)|BIT(PCINT17)|BIT(PCINT20)|BIT(PCINT21)|BIT(PCINT23)|BIT(PCINT22); // Enable Interrupts on inputs
	
	TCCR1B |= BIT(WGM12);					// Configure timer 1 for CTC mode
	TIMSK1 |= BIT(OCIE1A) | BIT(OCIE1B);	// Enable CTC interrupt

	sei(); // Turn on interrupts
	
	OCR1A = 15624;					// Set CTC compare value to .25Hz at 1 MHz AVR clock , with a prescaler of 64
	OCR1B = 15624;					// Set CTC compare value to .25Hz at 1 MHz AVR clock , with a prescaler of 64
	TCCR1B |= BIT(CS10) | BIT(CS11);// Start timer at Fcpu /64
	
	getInputs();
	
	boolean dr1BtnReleased=true, dr2BtnReleased=true;

//	MAIN LOOP:
	for(;;)	{
		
		//	Poll the Door 1 button
		if( !dr1.isActive && button_is_pressed(INPUT_PIN, DR1_BUTTON) )
		{
			if ( inputs.mode == DEPENDENT )
				dependentRetract();
			
			else // INDEPENDENT MODE
			{
 				if( dr1.toggled_mode && dr1BtnReleased ) /*Toggle if in toggle mode && button has been released*/
				{
					dr1BtnReleased=false; // Change the previous button state off
					dr1.isToggled = !dr1.isToggled;
					activateDoor1(dr1.isToggled);
				}
				else if(!dr1.toggled_mode) /*Activate door if not in toggle mode*/
				{
					
					
					
					ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { dr1.isActive = true; getInputs(); TCNT0=0; }
					activateDoor1(true);
					/*time1 = time1*4;*/
					/*time1 *= 4;*/
					//sbi(TIMSK1,OCIE1A); // Enable the timer1A interrupt
				}
			}
		} else 
			dr1BtnReleased=true;

		//	Poll the Door 2 button
		if( !dr2.isActive && button_is_pressed(INPUT_PIN, DR2_BUTTON) )
		{
			if ( inputs.mode == DEPENDENT )
				dependentRetract();
			
			else // INDEPENDENT MODE
			{
				if(dr2.toggled_mode && dr2BtnReleased) // Toggle if in toggle mode && button has been released
				{
					dr2BtnReleased=false; // Change the previous button state off
					dr2.isToggled = !dr2.isToggled;
					activateDoor2(dr2.isToggled);
				}
				else if(!dr2.toggled_mode)
				{
					/*getInputs();*/
					activateDoor2(true);
					dr2.isActive = true;
					/*time2 = time2*2;*/
					/*time2 *= 4;*/
					//sbi(TIMSK1,OCIE1B); // Enable the timer1B interrupt
				}
			}
		} else
			dr2BtnReleased=true;
		
		wdt_reset(); // Reset the watchdog timer
	}
}

// Timer1A Interrupt - Handles the door1 independent operation
ISR ( TIMER1_COMPA_vect ) {
	//sbi(PINB,PINB5);
	if(dr1.isActive){
		if(bit_is_clear(INPUT_PIN,DR1_BUTTON)) // Door1 Button is still pressed, reset the counter
			timer1A_counter = 0;
		else if(++timer1A_counter>=time1) // When the counter is >= time1, turn off door 1
		{ 
			activateDoor1(false);
			dr1.isActive = false;
			timer1A_counter = 0; // reset the counter for the next go round
			//cbi(TIMSK1,OCIE1A); // Disable the timer1A interrupt
		}
	}
}

// Timer1B Interrupt - Handles the door2 independent operation
ISR ( TIMER1_COMPB_vect ) {
	if(dr2.isActive){
		if(bit_is_clear(INPUT_PIN,DR2_BUTTON)) // Door2 Button is still pressed, reset the counter
			timer1B_counter=0;
		else if(++timer1B_counter>=time2) // When the counter is >= time2, turn off door 2
		{
			activateDoor2(false);
			dr2.isActive = false;
			timer1B_counter = 0; // reset the counter for the next go round
			//cbi(TIMSK1,OCIE1B); // Disable the timer1B interrupt
		}
	}
}