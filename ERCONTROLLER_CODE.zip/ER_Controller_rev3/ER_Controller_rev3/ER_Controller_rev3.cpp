/*
 * ER_Controller.c
 */ 

#include <avr/io.h>
#define F_CPU 1000000L	//  8MHz�CLK/8 = 1 MHz system clock
#include <util/delay.h>
#include <avr/pgmspace.h>
#include <avr/wdt.h>
#include <util/atomic.h>
#include <avr/interrupt.h>
#include <avr/portpins.h>

/*
OUTPUT DEFINITIONS:		*/
#define OUTPUT_PORT		PORTB	// Output port for Door1/2 and Signals1/2
#define OUTPUT_DDR		DDRB	// Data Direction Port for output
#define DR1_OUT			PB0		// Door 1 output pin
#define DR2_OUT			PB1		// Door 2 output pin
#define SIG1_OUT_PIN	PB2		// Signal 1 output pin
#define SIG2_OUT_PIN	PB3		// Signal 2 output pin

/*						
INPUT DEFINITIONS:		*/
#define INPUT_PIN			PIND	// Input Port for Door 1 & Door 2
#define INPUT_PORT			PORTD	// Input Port for Door 1 & Door 2
#define INPUT_DDR			DDRD	// Data Direction for Input Ports
#define MODE_PIN			PIND0	// Mode selection pin
#define TOGGLE1_PIN			PIND1	// Toggle Mode pin for Door 1
#define TOGGLE2_PIN			PIND7	// Toggle Mode pin for Door 2
#define DR1_BUTTON			PIND2	// Door 1 Input Pin
#define DR2_BUTTON			PIND3	// Door 2 Input Pin
#define ACTIVE_MODE1_PIN	PIND4	// Active Mode Pin for Door 1
#define ACTIVE_MODE2_PIN	PIND5	// Active Mode Pin for Door 2
#define DS_PORT				PORTC	// Digital Switch Input Port
#define DS_PIN_PORT			PINC	// Digital Switch Input Pin Port
#define DS_DDR				DDRC	// Data Direction for DS_PORT
#define DS1_PIN				PC0		// DS1 Control Output Pin
#define DS2_PIN				PC1		// DS2 Control Output Pin
#define TESTMODE_PIN_PORT	PINB	// Port for testmode
#define TESTMODE_PIN		PINB6	// Pin for entering test mode

/*
CONSTANT DEFINITIONS:	*/
#define DIFF_DELAY		500UL	// Differential Delay Time between door retractions(ms)
#define SIG_DELAY		600UL	// Signal Delay Time before activating door signals(ms)
#define DEBOUNCE_TIME	255		// Switch Debounce Time
#define DEPENDENT		0x1		// Operating Mode Types
#define INDEPENDENT		0x0
#define ACTIVE_HIGH		0x1		// Output Mode Types
#define ACTIVE_LOW		0x0

#ifndef true
#define true			(0==0)	// Boolean Types
#endif
#ifndef false
#define false			(0!=0)
#endif

#include "timers.h"
int testMode(uint8_t state);

// Global Variables for the various configurations
typedef struct {
	volatile boolean toggle_mode;
	volatile boolean isToggled;
	volatile boolean isActive;
	volatile uint8_t output_mode;
} door;

door dr1 = {false, false, false, ACTIVE_HIGH};
door dr2 = {false, false, false, ACTIVE_HIGH};

typedef struct inputs {
	boolean mode;
	const uint8_t inputPinMask;
} Inputs;

Inputs inputs = {DEPENDENT, (BIT(MODE_PIN) | BIT(TOGGLE1_PIN) | BIT(TOGGLE2_PIN) | BIT(DR1_BUTTON) | BIT(DR2_BUTTON) | BIT(ACTIVE_MODE1_PIN) | BIT(ACTIVE_MODE2_PIN)) };


//const uint8_t inputPinMask = 0b10110011;

// Global Variables for the various configurations
volatile uint8_t inputReg = 0x0;
volatile boolean retracting=false;
		
volatile unsigned long timer0_millis = 0;
static unsigned char timer0_fract = 0;

// Array holding the 4-bit timing selection values (in seconds)
const uint8_t PROGMEM timing_values_PGM[] = {
	1,	// 0
	2,	// 1
	5,	// 2
	10,	// 3
	15,	// 4
	20, // 5
	25,	// 6
	30,	// 7
	35,	// 8
	40, // 9
	45, // A
	50,	// B
	55,	// C
	60, // D
	90,	// E
	120,// F
};

#define getTimingValue(P) ( pgm_read_byte( timing_values_PGM + (P) ) )

void doorPinWrite(uint8_t doorPin, boolean active) {
	byte mode;
	if(doorPin==DR1_OUT){
		mode = active ? (bit_get(dr1.output_mode, 1)) : (!bit_get(dr1.output_mode, 1));
		bit_write( mode, OUTPUT_PORT, BIT(DR1_OUT) );
	} else {
		mode = active ? (bit_get(dr2.output_mode, 1)) : (!bit_get(dr2.output_mode, 1));
		bit_write( mode, OUTPUT_PORT, BIT(DR2_OUT));
	}
}

//  Returns the time or resets the timer
unsigned long door_timer(boolean reset) {
	if(reset) // Reset the Door 1 timer
	{
		ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
			timer0_millis = 0;
			timer0_fract = 0;
		}
		return 0;
	}
	// Else, return the time since last reset
	unsigned long t;
	ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
		t = timer0_millis;
	}
	return t;
}

unsigned long getTime1(void) {
	unsigned long t;
	sbi(DS_PORT, DS1_PIN);
	cbi(DS_PORT, DS2_PIN);
	uint8_t DSx_value = (DS_PIN_PORT & 0x3c)>>2;
	t = getTimingValue(DSx_value);
	cbi(DS_PORT, DS1_PIN);
	return t;
}

unsigned long getTime2(void) {
	unsigned long t2;
	sbi(DS_PORT, DS2_PIN);
	cbi(DS_PORT, DS1_PIN);
	uint8_t DSx_value = (DS_PIN_PORT & 0x3c)>>2;
	t2 = getTimingValue(DSx_value);
	cbi(DS_PORT, DS2_PIN);
	return t2;
}

void dependentRetract(void) {
//	In toggle mode?
	if(dr1.toggle_mode==true) {
		if(dr1.isToggled==true) // Outputs currently toggled, so toggle them off
		{
			doorPinWrite(DR1_OUT,false); // Door 1 off
			doorPinWrite(DR2_OUT,false); // Door 2 off
			cbi(OUTPUT_PORT, SIG1_OUT_PIN);	// Turn off door signal outputs
			cbi(OUTPUT_PORT, SIG2_OUT_PIN);
			dr1.isToggled = false;
			dr2.isToggled = false;
		} 	else { // Outputs not toggled, so toggle them now 
			ATOMIC_BLOCK(ATOMIC_RESTORESTATE){
				doorPinWrite(DR1_OUT,true); // Door 1 Active
				dr1.isToggled = true;
				_delay_ms(DIFF_DELAY); // Differential Delay
				wdt_reset(); // Reset the watchdog timer	
				doorPinWrite(DR2_OUT,true); // Door 2 Active
				dr2.isToggled = true;
				_delay_ms(SIG_DELAY);	// Door Signal Delay
				sbi(OUTPUT_PORT, SIG1_OUT_PIN);	// Turn on door signal outputs
				sbi(OUTPUT_PORT, SIG2_OUT_PIN);
			}			
			while( bit_is_clear(INPUT_PIN, DR1_BUTTON) || bit_is_clear(INPUT_PIN, DR2_BUTTON) ) // Maintain while buttons are held
				{ wdt_reset();  }
		}
	} else { // Not in toggle mode
		ATOMIC_BLOCK(ATOMIC_RESTORESTATE){
			retracting = true;
			doorPinWrite(DR1_OUT,true); // Door 1 Active
			_delay_ms(DIFF_DELAY); // Differential Delay
			doorPinWrite(DR2_OUT,true); // Door 2 Active
			_delay_ms(SIG_DELAY);	// Door Signal Delay
			sbi(OUTPUT_PORT, SIG1_OUT_PIN);	// Activate door signal outputs
			sbi(OUTPUT_PORT, SIG2_OUT_PIN);
		}
		door_timer(true); // Reset the Door timer
		unsigned long t;
		while( door_timer(false) <= ((t=getTime1())*1000) ) // Hold Time Delay, value set from DS1
		{
			wdt_reset(); // Reset the watchdog timer
			if( bit_is_clear(INPUT_PIN, DR1_BUTTON) || bit_is_clear(INPUT_PIN, DR2_BUTTON) )	// Maintain active outputs when button is held
				door_timer(true); // reset the timer 
			if(inputs.mode==INDEPENDENT) // If mode changed, break loop
				break;
		}
		doorPinWrite(DR1_OUT,false); // Door outputs off
		doorPinWrite(DR2_OUT,false);
		cbi(OUTPUT_PORT, SIG1_OUT_PIN);	// Deactivate door signal outputs
		cbi(OUTPUT_PORT, SIG2_OUT_PIN);
		retracting = false;
	}
}

void activateDoor1(boolean activate){
	doorPinWrite(DR1_OUT, activate);
	activate ? _delay_ms(SIG_DELAY) : _delay_ms(0);
	activate ? sbi(OUTPUT_PORT,SIG1_OUT_PIN) : cbi(OUTPUT_PORT,SIG1_OUT_PIN);
	wdt_reset(); // Reset the watchdog timer
}

void activateDoor2(boolean activate){
	doorPinWrite(DR2_OUT, activate);
	activate ? _delay_ms(SIG_DELAY) : _delay_ms(0);
	activate ? sbi(OUTPUT_PORT,SIG2_OUT_PIN) : cbi(OUTPUT_PORT,SIG2_OUT_PIN);
	wdt_reset(); // Reset the watchdog timer
}

// Initialize the global variables
void getInputs(void) {
	inputReg = INPUT_PIN & inputs.inputPinMask;
	
	if( bit_is_set(inputReg,0) ) { inputs.mode = DEPENDENT; }
	else { inputs.mode = INDEPENDENT; }
	
	if( bit_is_set(inputReg,TOGGLE1_PIN) ) { dr1.toggle_mode = false; }
	else { dr1.toggle_mode = true; }
	
	if( bit_is_set(inputReg,ACTIVE_MODE1_PIN) ) { dr1.output_mode = ACTIVE_HIGH; }
	else { dr1.output_mode = ACTIVE_LOW; }
	
	if( bit_is_set(inputReg,ACTIVE_MODE2_PIN) ) { dr2.output_mode = ACTIVE_HIGH; }
	else { dr2.output_mode = ACTIVE_LOW; }
		
	if( bit_is_set(inputReg,ACTIVE_MODE2_PIN) ) { dr2.output_mode = ACTIVE_HIGH; }
	else { dr2.output_mode = ACTIVE_LOW; }
		
	if( bit_is_set(inputReg,TOGGLE2_PIN) ) { dr2.toggle_mode = false; }
	else { dr2.toggle_mode = true; }
}

int main(void) {

//	INIT:
	INPUT_PIN = 0xff;	// Enable the Input Port internal pull-ups
	INPUT_DDR = 0x00;	// Initialize Input Port as inputs
	
 	OUTPUT_DDR = 0b00111111;	// Output Port initialized as outputs

	//sbi(OUTPUT_PORT,PB7); // Enable pullup on test mode pin
	
	DS_DDR = ( BIT(DS1_PIN) | BIT(DS2_PIN) );	// PC0 & PC1 set as outputs for DS switches
	
	wdt_reset();
	wdt_enable(WDTO_2S); // Enable Watchdog Timer @ 2 second time-out
	
 	sbi(PCICR,PCIE2); // Enable Pin Change Interrupt 2
 	PCMSK2 = BIT(PCINT16)|BIT(PCINT17)|BIT(PCINT20)|BIT(PCINT21)|BIT(PCINT23)|BIT(PCINT22); // Enable Interrupts on input pins
	
	TCCR0A |= BIT(CS01)|BIT(CS00); // Initialize timer0 with a prescaler of 64
	sbi(TIMSK0, TOIE0); 	// enable timer 0 overflow interrupt
	
	TCCR1B |= (1 << WGM12 ); // Configure timer 1 for CTC mode
	TIMSK1 |= BIT(OCIE1A); // Enable Output Compare Interrupt Channel A
	
	sei(); // Turn on interrupts

 	OCR1A = 1562; // Set CTC compare value to 0.2Hz at 1 MHz AVR clock , with a prescaler of 64
	TCCR1B |= ((1 << CS10 ) | (1 << CS11 )); // Start timer at Fcpu /64
	
	getInputs();
	
	//if( button_is_pressed(TESTMODE_PIN_PORT, BIT(TESTMODE_PIN)) ) {
// 	if( button_is_pressed(INPUT_PIN, DR1_BUTTON) ) {
// 		if( button_is_pressed(INPUT_PIN, DR2_BUTTON) ) {
// 			uint8_t i=0;
// 			OUTPUT_PORT |= 0xff;
// 			while( testMode(i) != 1 ) { wdt_reset(); i++; if(i>2) i=0; }
// 		}		
// 	}
	
	boolean dr1BtnReleased=true, dr2BtnReleased=true;

//	MAIN LOOP:
	for(;;)	{
		
	   /*********************
		*	Dependent Mode	*
		*********************/
		
		if(inputs.mode==DEPENDENT) {
			if( bit_is_clear(INPUT_PIN, DR1_BUTTON) || bit_is_clear(INPUT_PIN, DR2_BUTTON) )
				dependentRetract();
		}
		
		
	   /*************************
		*	Independent Mode	*
		*************************/
		
		else if(inputs.mode==INDEPENDENT) {
		
			//	Poll the Door 1 button
			if( !dr1.isActive && bit_is_clear(INPUT_PIN, DR1_BUTTON) ) {
				// Toggle if in toggle mode && button has been released
				if( dr1.toggle_mode && dr1BtnReleased ) {
					dr1BtnReleased=false; // Change the previous button state off
					dr1.isToggled = !dr1.isToggled;
					activateDoor1(dr1.isToggled);
				}
				
				// Activate door if not in toggle mode
				else if(!dr1.toggle_mode) {
					dr1.isActive = true;
					activateDoor1(true);
				}
			} else dr1BtnReleased=true;
			
			
			//	Poll the Door 2 button
			if( !dr2.isActive && bit_is_clear(INPUT_PIN, DR2_BUTTON) ) {
			
				// Toggle if in toggle mode && button has been released
				if(dr2.toggle_mode && dr2BtnReleased) {
					dr2BtnReleased=false; // Change the previous button state off
					dr2.isToggled = !dr2.isToggled;
					activateDoor2(dr2.isToggled);
				}
				
				// Activate door if not in toggle mode
				else if(!dr2.toggle_mode) {
					dr2.isActive = true;
					activateDoor2(true);
				}
			} else dr2BtnReleased=true;
			
		}
		
		//	Reprocess inputs if any have changed
		if( inputReg != (INPUT_PIN & inputs.inputPinMask) )
			getInputs();
			
		wdt_reset(); // Reset the watchdog timer
		
	}
}

volatile unsigned long door1_counter=0, door2_counter=0;

// Timer1A Compare Interrupt - Handles the independent operation
ISR ( TIMER1_COMPA_vect ) {
	
	unsigned long t;
	
	// Door 1 
	if(dr1.isActive) {
		if(bit_is_clear(INPUT_PIN, DR1_BUTTON)) // Door1 Button is still pressed, reset the counter
			door1_counter = 0;
		else if( ++door1_counter > ((t=getTime1())*10) ) // When the counter is >= time1, turn off door 1
		{
			activateDoor1(false);
			dr1.isActive = false;
			door1_counter = 0; // reset the counter for the next go round
		}
	}
	
	// Door 2
	if(dr2.isActive) {
		if(bit_is_clear(INPUT_PIN, DR2_BUTTON)) // Door2 Button is still pressed, reset the counter
			door2_counter=0;
		else if( ++door2_counter > ((t=getTime2())*10) ) // When the counter is >= time2, turn off door 2
		{
			activateDoor2(false);
			dr2.isActive = false;
			door2_counter = 0; // reset the counter for the next go round
		}
	}
}

// Timer0 overflow interrupt - Increments the millis variable
// ISR(TIMER0_OVF_vect) {
// 	unsigned long m = timer0_millis;
// 	unsigned char f = timer0_fract;
// 	
// 	m += MILLIS_INC;
// 	f += FRACT_INC;
// 
// 	if (f >= FRACT_MAX) {
// 		f -= FRACT_MAX;
// 		m += 1;
// 	}
// 	timer0_fract = f;
// 	timer0_millis = m;
// }

/*
Interrupt Handler For PCINT23:16 (PIND)
This routine changes the global variables and resynchronizes
the outputs to correspond with the changes	*/ 
ISR(PCINT2_vect) {
	// The set bits in 'reg' corresponds to the changed pin inputs
	uint8_t reg = (INPUT_PIN^inputReg);
	
	if(  bit_is_set(reg, 0) ) // Operating Mode Changed
	{
		// Set the operating mode
		if( bit_get(INPUT_PIN, BIT(MODE_PIN) ) )
		inputs.mode = DEPENDENT;
		else
		inputs.mode = INDEPENDENT;
			
		// Change the input register value
		bit_write(inputs.mode, inputReg, BIT(0));
			
		// Turn off any active outputs for the new mode
		doorPinWrite(DR1_OUT,false);
		doorPinWrite(DR2_OUT,false);
		cbi(OUTPUT_PORT,SIG1_OUT_PIN);
		cbi(OUTPUT_PORT,SIG2_OUT_PIN);
		dr2.isToggled = false;
		dr1.isToggled = false;
		dr1.isActive = false;
		dr2.isActive = false;
		retracting = false;
		door_timer(false);
	}
		
	if( bit_is_set(reg, 4) ) // Door 1 Active Mode Changed
	{
		// Set the Door 1 active mode
		if( bit_get(INPUT_PIN,BIT(ACTIVE_MODE1_PIN)) ) {
			dr1.output_mode = ACTIVE_HIGH;
			sbi(inputReg,ACTIVE_MODE1_PIN);
		} else {
			dr1.output_mode = ACTIVE_LOW;
			cbi(inputReg,ACTIVE_MODE1_PIN);
		}
			
		if( dr1.isActive || dr1.isToggled || retracting) // If Door 1 is active anywhere ? Door 1 Output = Active Mode 1
			doorPinWrite(DR1_OUT,true);
		else										 // Otherwise ? Door 1 Output = !Active Mode
			doorPinWrite(DR1_OUT,false);
	}

	if( bit_is_set(reg, 5) ) // Door 2 Active Mode Changed
	{
		// Set the Door 2 active mode
		if( bit_get(INPUT_PIN,BIT(ACTIVE_MODE2_PIN)) ) {
			dr2.output_mode = ACTIVE_HIGH;
			sbi(inputReg, ACTIVE_MODE2_PIN);
		} else {
			dr2.output_mode = ACTIVE_LOW;
			cbi(inputReg, ACTIVE_MODE2_PIN);
		}
			
		if( dr2.isActive || dr2.isToggled || retracting) // If Door 2 is active anywhere -> Door 2 Output = Active Mode 2
			doorPinWrite(DR2_OUT,true);
		else										 // Otherwise -> Door 2 Output = !Active Mode 2
			doorPinWrite(DR2_OUT,false);
	}
		
	if( bit_is_set(reg, 1) ) // Door 1 Toggle Mode Changed
	{
		// Set the door 1 toggle value
		if( bit_get(INPUT_PIN, BIT(TOGGLE1_PIN)) ) {
			dr1.toggle_mode = false;
			sbi(inputReg,TOGGLE1_PIN);
		} else {
			dr1.toggle_mode = true;
			cbi(inputReg,TOGGLE1_PIN);
		}
			
		if( dr1.isToggled && dr1.toggle_mode==false ) // Toggle mode changed to off and output is toggled!
		{
			doorPinWrite(DR1_OUT,false);
			cbi(OUTPUT_PORT,SIG1_OUT_PIN);
			dr1.isToggled = false;
			if(inputs.mode==DEPENDENT){
				doorPinWrite(DR2_OUT,false);
				cbi(OUTPUT_PORT,SIG2_OUT_PIN);
				dr2.isToggled = false;
			}
		}
		bit_write( !bit_get(dr1.toggle_mode,BIT(0)), inputReg, BIT(1)); // Change the input register value
	}

	if( bit_is_set(reg, 7) )// Door 2 Toggle Mode Changed
	{
		// Set the door 2 toggle value
		if( bit_get(INPUT_PIN, BIT(TOGGLE2_PIN)) ) {
			dr2.toggle_mode = false;
			sbi(inputReg,TOGGLE2_PIN);
		} else {
			dr2.toggle_mode = true;
			cbi(inputReg,TOGGLE2_PIN);
		}
			
		if( dr2.isToggled && dr2.toggle_mode==false && inputs.mode == INDEPENDENT) //Toggle mode changed to off and output is toggled!
		{
			doorPinWrite(DR2_OUT,false);
			cbi(OUTPUT_PORT,SIG2_OUT_PIN);
			dr2.isToggled = false;
		}
		bit_write( !bit_get(dr2.toggle_mode,BIT(0)), inputReg, BIT(7)); // Change the input register value
	}
}

int testMode(uint8_t state) {
	
	//OUTPUT_PORT = ~0x55;
	
	// Check DS switches - User to set DS1 to 5, DS2 to A
// 	sbi(DS_PORT, DS1_PIN);
// 	cbi(DS_PORT, DS2_PIN);
	
	//wdt_reset();
	unsigned long ds_val;
	unsigned long time_val;
	here:
	wdt_reset();
	switch (state) {
		
		case 0:
			ds_val = getTime1();
			time_val = getTimingValue(0x5);
			if ( ds_val != time_val )
				cbi(OUTPUT_PORT, 0);
			else {
				sbi(OUTPUT_PORT, 0);
				state++;
				break;
			}			
			goto here;

		case 1:
			ds_val = getTime2();
			time_val = getTimingValue(0xA);
			if ( ds_val != time_val )
				cbi(OUTPUT_PORT, 1);
			else {
				sbi(OUTPUT_PORT, 1);
				state++;
				while( bit_is_set(INPUT_PIN,DR1_BUTTON) ) { wdt_reset(); }
				break;
			}				
			goto here;

		case 2:
			ds_val = getTime1();
			time_val = getTimingValue(0xA);
			if ( ds_val != time_val )
				cbi(OUTPUT_PORT, 2);
			else {
				sbi(OUTPUT_PORT, 2);
				state++;
				break;
			}
			goto here;
			
		case 3:
			ds_val = getTime2();
			time_val = getTimingValue(0x5);
			if ( ds_val != time_val )
				cbi(OUTPUT_PORT, 3);
			else {
				sbi(OUTPUT_PORT, 3);
				break;
			}
			goto here;
			
		default:
			goto here;
		
	}
	
	return 1;
	
	
}