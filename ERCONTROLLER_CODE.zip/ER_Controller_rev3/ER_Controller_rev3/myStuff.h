/*
 * myStuff.h
 *
 * Created: 7/25/2012 2:07:38 PM
 *  Author: dmh
 */ 

#ifndef MYSTUFF_H_
#define MYSTUFF_H_

#include <avr/interrupt.h>
#include <avr/wdt.h>

#ifndef boolean
typedef uint8_t boolean;
#endif
#ifndef byte
typedef uint8_t byte;
#endif

#ifndef cbi
#define cbi(sfr, bit) (_SFR_BYTE(sfr) &= ~_BV(bit))
#endif
#ifndef sbi
#define sbi(sfr, bit) (_SFR_BYTE(sfr) |= _BV(bit))
#endif


// #define LOW 0x0
// #define HIGH 0x1
//#define constrain(amt,low,high) ((amt)<(low)?(low):((amt)>(high)?(high):(amt)))
//#define ledPin PORTD0
// #define delayPin1 PORTC0
// #define delayPin2 PORTC1
// #define IND_RETRACTING 0x2
// #define DEP_RETRACTING 0x1
// #define IDLE 0x0
#define nop __asm__("nop\n\t");

#define F_CPU 8000000UL	// 8 MHz system clock
#include <util/delay.h>
#define clockCyclesPerMicrosecond() ( F_CPU / 1000000L )
#define clockCyclesToMicroseconds(a) ( (a) / clockCyclesPerMicrosecond() )
#define MICROSECONDS_PER_TIMER0_OVERFLOW (clockCyclesToMicroseconds(64 * 256))
#define MILLIS_INC (MICROSECONDS_PER_TIMER0_OVERFLOW / 1000)
#define FRACT_INC ((MICROSECONDS_PER_TIMER0_OVERFLOW % 1000) >> 3)
#define FRACT_MAX (1000 >> 3)
//#define dr1_out_bitValue(uint8_t)( 1 & (PORTB>>dr1_out_pin) )
//#define dr2_out_bitValue(uint8_t)( 1 & (PORTB>>dr2_out_pin) )
//#define SETBITS(x,y) ((x) |= (y))

#define bit_get(p,m1) ((p) & (m1))
#define bit_set(p,m1) ((p) |= (m1))
#define bit_clear(p,m1) ((p) &= ~(m1))
#define bit_write(c,p,m1) (c ? bit_set(p,m1) : bit_clear(p,m1))
#define BIT(x) (0x01 << (x))

//#define bit_flip(p,m) ((p) ^= (m))
//#define LONGBIT(x) ((unsigned long)0x00000001 << (x))

/*
ISR(INT0_vect)
{
 	return;
}

ISR(INT1_vect)
{
 		return;
}
*/

volatile unsigned long timer0_overflow_count = 0;
volatile unsigned long timer0_millis = 0;
static unsigned char timer0_fract = 0;

volatile unsigned long dr1_timer0_overflow_count = 0;
volatile unsigned long dr1_timer0_millis = 0;
static unsigned char dr1_timer0_fract = 0;

volatile unsigned long dr2_timer0_overflow_count = 0;
volatile unsigned long dr2_timer0_millis = 0;
static unsigned char dr2_timer0_fract = 0;

// Interrupt handler for timer0 overflow
SIGNAL(TIMER0_OVF_vect)
{
	// copy these to local variables so they can be stored in registers
	// (volatile variables must be read from memory on every access)
	unsigned long m = timer0_millis, m1 = dr1_timer0_millis, m2=dr2_timer0_millis;
	unsigned char f = timer0_fract, f1 = dr1_timer0_fract, f2 = dr2_timer0_fract;
	
	m += MILLIS_INC; m1 += MILLIS_INC; m2 += MILLIS_INC;
	f += FRACT_INC; f1 += FRACT_INC; f2 += FRACT_INC;
	if (f >= FRACT_MAX) {
		f -= FRACT_MAX;
		m += 1;
	}
	if (f1 >= FRACT_MAX) {
		f1 -= FRACT_MAX;
		m1 += 1;
	}
	if (f2 >= FRACT_MAX) {
		f2 -= FRACT_MAX;
		m2 += 1;
	}
	
	timer0_fract = f; dr1_timer0_fract = f1; dr2_timer0_fract = f2;
	timer0_millis = m; dr1_timer0_millis = m1; dr2_timer0_millis = m2;
	timer0_overflow_count++; dr1_timer0_overflow_count++; dr2_timer0_overflow_count++;
}

unsigned long millis(void) {
	unsigned long m;
	uint8_t oldSREG = SREG;
	// disable interrupts while we read timer0_millis or we might get an
	// inconsistent value (e.g. in the middle of a write to timer0_millis)
	cli();
	m = timer0_millis;
	SREG = oldSREG;
	return m;
}

unsigned long door1_time(boolean reset) {
	
	uint8_t oldSREG = SREG;
	if(reset) {
		cli();
		dr1_timer0_millis = 0;
		dr1_timer0_fract = 0;
		SREG = oldSREG;
		return 0;
	}
	
	unsigned long m1;
	
	// disable interrupts while we read timer0_millis or we might get an
	// inconsistent value (e.g. in the middle of a write to timer0_millis)
	cli();
	m1 = dr1_timer0_millis;
	SREG = oldSREG;
	return m1;
}

unsigned long door2_time(boolean reset) {
	
	uint8_t oldSREG = SREG;
	if(reset) {
		cli();
		dr2_timer0_millis = 0;
		dr2_timer0_fract = 0;
		SREG = oldSREG;
		return 0;
	}
	
	unsigned long m2;
	// disable interrupts while we read timer0_millis or we might get an
	// inconsistent value (e.g. in the middle of a write to timer0_millis)
	cli();
	m2 = dr2_timer0_millis;
	SREG = oldSREG;
	return m2;
}

void startTimer(boolean start)
{
	if(start)
	{
// 		sbi(EIMSK, INT1);	// enable int1
// 		sbi(EIMSK, INT0);	// enable int0
		uint8_t oldSREG = SREG;
		cli();
		timer0_overflow_count = 0;	// Reset variables to zero
		timer0_millis = 0;
		timer0_fract = 0;
		SREG = oldSREG;
		sbi(TIMSK, TOIE0); // enable timer 0 overflow interrupt
	}
	else
		cbi(TIMSK, TOIE0); // Disable Timer 0 Overflow Interrupt
}

// long map(long x, long in_min, long in_max, long out_min, long out_max)
// {
// 	return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
// }

void WDT_Prescaler_Change(void)
{
	cli();
	wdt_reset();
	//MCUSR |= (1&(0<<WDRF));
	/* Start timed sequence */
	MCUSR |= (1<<WDRF);
	WDTCSR = (1<<WDCE) | (1<<WDE);
	/* Set new prescaler(time-out) value = 64K cycles (~0.5 s) */
	WDTCSR = (1<<WDE) | (1<<WDP2) | (1<<WDP1) | BIT(WDP0) ; //| (1<<WDE) //(1<<WDP2) | (1<<WDP0) | (1<<WDP1);
	
	
// 	
// 	sei();
}


#endif /* MYSTUFF_H_ */