/*
 * ER_Controller.c
 */ 

// Includes:
#include <avr/io.h>
#include <util/delay.h>
#include <avr/wdt.h>
#include <util/atomic.h>
#include <avr/interrupt.h>
#include <avr/portpins.h>
#include <avr/sfr_defs.h>
#include "Includes/timers.h"
#include "Includes/interrupts.h"
#include "Includes/ER_Controller_rev4.h"

Door dr1 = {false,false,false,ACTIVE_HIGH};
Door dr2 = {false,false,false,ACTIVE_HIGH};
Inputs inputs = {DEPENDENT, 0x00, false};

int main(void) {

	// Setup:
	//INPUT_PIN = INPUT_MASK;	// Enable the Input Port internal pull-ups
	//INPUT_DDR = 0x00;		// Initialize Input Port as inputs
	
 	OUTPUT_DDR = ( bit(DR1_OUT)|bit(DR2_OUT)|bit(SIG1_OUT_PIN)|bit(SIG2_OUT_PIN) );	// Initialize output port
	DS_DDR = ( BIT(DS1_PIN) | BIT(DS2_PIN) );	// PC0 & PC1 set as outputs for DS switches
	
	//sbi(OUTPUT_PORT,PB7); // Enable pullup on test mode pin
	
	wdt_reset();
	wdt_enable(WDTO_2S); // Enable Watchdog Timer @ 2 second time-out
	
	
	//if(DS_PIN_PORT&(0xFF & ))
	
 	sbi(PCICR,PCIE2); // Enable Pin Change Interrupt 2	
 	PCMSK2 = BIT(PCINT16)|BIT(PCINT17)|BIT(PCINT20)|BIT(PCINT21)|BIT(PCINT23)|BIT(PCINT22); // Enable Interrupts on input pins
	
	TCCR0A |= BIT(CS01)|BIT(CS00); // Initialize timer0 with a prescaler of 64
	sbi(TIMSK0, TOIE0); 	// enable timer 0 overflow interrupt
	
	TCCR1B |= (1 << WGM12 ); // Configure timer 1 for CTC mode
	TIMSK1 |= BIT(OCIE1A); // Enable Output Compare Interrupt Channel A

	sei(); // Turn on interrupts

 	OCR1A = 1562; // Set CTC compare value to 0.2Hz at 1 MHz AVR clock , with a prescaler of 64
	TCCR1B |= ((1 << CS10 ) | (1 << CS11 )); // Start timer at Fcpu /64
	
	getInputs();
	
	// Set the outputs in the case of Active LOW settings
	doorPinWrite(DR1_OUT, ((dr1.isActive||dr1.isToggled||inputs.retracting) ? true:false) );
	doorPinWrite(DR2_OUT, ((dr2.isActive || dr2.isToggled||inputs.retracting) ? true:false) );	
	
	//if( button_is_pressed(TESTMODE_PIN_PORT, BIT(TESTMODE_PIN)) ) {
// 	if( button_is_pressed(INPUT_PIN, DR1_BUTTON) ) {
// 		if( button_is_pressed(INPUT_PIN, DR2_BUTTON) ) {
// 			uint8_t i=0;
// 			OUTPUT_PORT |= 0xff;
// 			while( testMode(i) != 1 ) { wdt_reset(); i++; if(i>2) i=0; }
// 		}		
// 	}
	
	boolean dr1BtnReleased=true, dr2BtnReleased=true;
	
	// MAIN LOOP:
	for(;;)	{
		
	   /*********************
		*	Dependent Mode	*
		*********************/
		
		if(inputs.mode==DEPENDENT) {
			if(  button_is_pressed(&INPUT_PIN, DR2_BUTTON) || button_is_pressed(&INPUT_PIN, DR1_BUTTON) )
				dependentRetract();
		}
		
		
	   /*************************
		*	Independent Mode	*
		*************************/
		
		else if(inputs.mode==INDEPENDENT) {
		
			//	Poll the Door 1 button
			if( button_is_pressed(&INPUT_PIN, DR1_BUTTON) && !dr1.isActive ) {
				// Toggle if in toggle mode && button has been released
				if( dr1.toggleMode && dr1BtnReleased ) {
					dr1BtnReleased=false; // Change the previous button state off
					dr1.isToggled = !dr1.isToggled;
					activateDoor1(dr1.isToggled);
				}
				
				// Activate door if not in toggle mode
				else if(!dr1.toggleMode) {
					dr1.isActive = true;
					activateDoor1(true);
				}
			} else dr1BtnReleased=true;
			
			
			//	Poll the Door 2 button
			if( button_is_pressed(&INPUT_PIN, DR2_BUTTON) && !dr2.isActive ) {
				// Toggle if in toggle mode && button has been released
				if(dr2.toggleMode && dr2BtnReleased) {
					dr2BtnReleased=false; // Change the previous button state off
					dr2.isToggled = !dr2.isToggled;
					activateDoor2(dr2.isToggled);
				}
				// Activate door if not in toggle mode
				else if(!dr2.toggleMode) {
					dr2.isActive = true;
					activateDoor2(true);
				}
			} else dr2BtnReleased=true;
		}
		
		//	Reprocess inputs if any have changed
		if( inputs.inputReg != (INPUT_PIN & INPUT_MASK) )
			getInputs();
			
		wdt_reset(); // Reset the watchdog timer
	}
}

// Get the configuration from the DIP switch
void getInputs(void) {
		inputs.inputReg = INPUT_PIN & INPUT_MASK;
		inputs.mode = bit_is_set(inputs.inputReg, MODE_PIN) ? DEPENDENT : INDEPENDENT;
		dr1.toggleMode = bit_is_set(inputs.inputReg, TOGGLE1_PIN) ? false : true;
		dr1.outputMode = (bit_get(INPUT_PIN, ACTIVE_MODE1_PIN)) ? ACTIVE_HIGH:ACTIVE_LOW;
		dr2.toggleMode = bit_is_set(inputs.inputReg,TOGGLE2_PIN) ? false : true;
		dr2.outputMode = (bit_get(INPUT_PIN, ACTIVE_MODE2_PIN)) ? ACTIVE_HIGH:ACTIVE_LOW;
}

// Sets or clears the door output pins
void doorPinWrite(uint8_t _doorPin, boolean _active) {
	byte _mode, _outputMode;
	_outputMode = (_doorPin==DR1_OUT) ? dr1.outputMode : dr2.outputMode;
	_mode = (_active) ? bit_get(_outputMode, 0) : !bit_get(_outputMode, 0);
	bit_write(_mode, OUTPUT_PORT, bit(_doorPin));
}

void dependentRetract(void) {
	
	//	In toggle mode?
	if(dr1.toggleMode==true) {
		if(dr1.isToggled==true) // Outputs currently toggled, so toggle them off
		{
			doorPinWrite(DR1_OUT,false); // Door 1 off
			doorPinWrite(DR2_OUT,false); // Door 2 off
			cbi(OUTPUT_PORT, SIG1_OUT_PIN);	// Turn off door signal outputs
			cbi(OUTPUT_PORT, SIG2_OUT_PIN);
			dr1.isToggled = false;
			dr2.isToggled = false;
		} 	else { // Outputs not toggled, so toggle them now 
				ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
					doorPinWrite(DR1_OUT,true); // Door 1 Active
					dr1.isToggled = true;
					_delay_ms(DIFF_DELAY); // Differential Delay
					wdt_reset(); // Reset the watchdog timer	
					doorPinWrite(DR2_OUT,true); // Door 2 Active
					dr2.isToggled = true;
					_delay_ms(SIG_DELAY);	// Door Signal Delay
					sbi(OUTPUT_PORT, SIG1_OUT_PIN);	// Turn on door signal outputs
					sbi(OUTPUT_PORT, SIG2_OUT_PIN);
				}
			}
		while( bit_is_clear(INPUT_PIN, DR1_BUTTON) || bit_is_clear(INPUT_PIN, DR2_BUTTON) ) // Maintain while buttons are held
			wdt_reset();
	} else { // Not in toggle mode
		ATOMIC_BLOCK(ATOMIC_RESTORESTATE){
			inputs.retracting = true;
			doorPinWrite(DR1_OUT,true); // Door 1 Active
			_delay_ms(DIFF_DELAY); // Differential Delay
			doorPinWrite(DR2_OUT,true); // Door 2 Active
			_delay_ms(SIG_DELAY);	// Door Signal Delay
			sbi(OUTPUT_PORT, SIG1_OUT_PIN);	// Activate door signal outputs
			sbi(OUTPUT_PORT, SIG2_OUT_PIN);
		}
		door_timer(true); // Reset the Door timer
		unsigned long t;
		while( door_timer(false) <= ((t=getTime(DR1_OUT))*1000) ) // Hold Time Delay, value set from DS1
		{
			wdt_reset(); // Reset the watchdog timer
			if( dr1.toggleMode==true )
				break;
			if( bit_is_clear(INPUT_PIN, DR1_BUTTON) || bit_is_clear(INPUT_PIN, DR2_BUTTON) )	// Maintain active outputs when button is held
				door_timer(true); // reset the timer 
			if(inputs.mode==INDEPENDENT || dr1.toggleMode==true) // If output or toggle mode changed, break loop
				break;
		}
		doorPinWrite(DR1_OUT,false); // Door outputs off
		doorPinWrite(DR2_OUT,false);
		cbi(OUTPUT_PORT, SIG1_OUT_PIN);	// Deactivate door signal outputs
		cbi(OUTPUT_PORT, SIG2_OUT_PIN);
		inputs.retracting = false;
	}
}

void activateDoor1(boolean activate){
	if(activate==false){
		doorPinWrite(DR1_OUT,false);
		cbi(OUTPUT_PORT,SIG1_OUT_PIN);
	} else {
// 		ATOMIC_BLOCK(ATOMIC_RESTORESTATE) // Ensure the following code completes before running an interrupt
// 		{
			doorPinWrite(DR1_OUT,true);
			
			// _delay_ms(SIG_DELAY);
			boolean dr2BtnPressed = false;
			
			// reset the timer
			door_timer(true);
			
			// Monitor the second input while waiting for
			// the signal delay to 
			while( (door_timer(false)) <= SIG_DELAY) {
				if(bit_is_clear(INPUT_PIN, DR2_BUTTON))
					dr2BtnPressed = true;
			}
			
			// Activate relay 1
			sbi(OUTPUT_PORT, SIG1_OUT_PIN);
			
			// Activate Door 2 if button was pressed
			if(dr2BtnPressed /*&& !dr2.isActive*/) {
				activateDoor2(true);
				dr2.isActive = true;
			}
		//}
	}
	wdt_reset(); // Reset the watchdog timer
}

void activateDoor2(boolean activate){
	if(activate==false){
		doorPinWrite(DR2_OUT,false);
		cbi(OUTPUT_PORT,SIG2_OUT_PIN);
	} else {
// 		ATOMIC_BLOCK(ATOMIC_RESTORESTATE) // Ensure the following code completes before running an interrupt
// 		{
			doorPinWrite(DR2_OUT, true);
			
			boolean dr1BtnPressed = false;
			
			//_delay_ms(SIG_DELAY);
			
			door_timer(true);
			
			while((door_timer(false)) <= SIG_DELAY) {
				if(bit_is_clear(INPUT_PIN, DR1_BUTTON))
					dr1BtnPressed = true;
			}
			
			// Activate relay 2
			sbi(OUTPUT_PORT,SIG2_OUT_PIN);
			
			// Activate door 2 if button was pressed
			// and is not active
			if(dr1BtnPressed /*&& !dr1.isActive*/) {
				activateDoor2(true);
				dr1.isActive = true;
			}
			
		//}
	}
	wdt_reset(); // Reset the watchdog timer
}

boolean button_is_pressed(uint8_t *PIN, uint8_t BUTTON_BIT) {
	// the button is pressed when BUTTON_BIT is clear
	if ( bit_is_clear(*PIN, BUTTON_BIT) )	{
		_delay_ms(DEBOUNCE_TIME);
		if (bit_is_clear(*PIN, BUTTON_BIT) ) return true;
	}
	return false;
}

int testMode(uint8_t state) {
	
	
	sbi(DS_PORT, DS1_PIN);
	cbi(DS_PORT, DS2_PIN);
	uint8_t m_dsport;
	
	while( (DS_PIN_PORT & 0x3c) == 0xF0  ) {
		
		wdt_reset(); // Reset
		sbi(OUTPUT_PORT, DR1_OUT);
		
	}
	
	cbi(OUTPUT_PORT, DR1_OUT);
	
	//OUTPUT_PORT = ~0x55;
	
	// Check DS switches - User to set DS1 to 5, DS2 to A
 	//sbi(DS_PORT, DS1_PIN);
 	//cbi(DS_PORT, DS2_PIN);
	
	//wdt_reset();
	//unsigned long ds_val;
	//unsigned long time_val;
	////here:
	//wdt_reset();
	//switch (state) {
		//
		//case 0:
			//ds_val = getTime(DR1_OUT);
			//time_val = getTimingValue(0x5);
			//if ( ds_val != time_val )
				//cbi(OUTPUT_PORT, 0);
			//else {
				//sbi(OUTPUT_PORT, 0);
				//state++;
				//break;
			//}			
			//goto here;
//
		//case 1:
			//ds_val = getTime(DR2_OUT);
			//time_val = getTimingValue(0xA);
			//if ( ds_val != time_val )
				//cbi(OUTPUT_PORT, 1);
			//else {
				//sbi(OUTPUT_PORT, 1);
				//state++;
				//while( bit_is_set(INPUT_PIN,DR1_BUTTON) ) { wdt_reset(); }
				//break;
			//}				
			//goto here;
//
		//case 2:
			//ds_val = getTime(DR1_OUT);
			//time_val = getTimingValue(0xA);
			//if ( ds_val != time_val )
				//cbi(OUTPUT_PORT, 2);
			//else {
				//sbi(OUTPUT_PORT, 2);
				//state++;
				//break;
			//}
			//goto here;
			//
		//case 3:
			//ds_val = getTime(DR2_OUT);
			//time_val = getTimingValue(0x5);
			//if ( ds_val != time_val )
				//cbi(OUTPUT_PORT, 3);
			//else {
				//sbi(OUTPUT_PORT, 3);
				//break;
			//}
			//goto here;
			//
		//default:
			//goto here;
		//
	//}
	//
	//return 1;
	
}
