/*
 * interrupts.h
 *
 * Created: 11/13/2012 4:03:32 PM
 *  Author: dmh
 */ 


#ifndef INTERRUPTS_H_
#define INTERRUPTS_H_

#include "ER_Controller_rev4.h"
#include "timers.h"

volatile unsigned long timer0_millis;
static unsigned char timer0_fract;


#endif /* INTERRUPTS_H_ */