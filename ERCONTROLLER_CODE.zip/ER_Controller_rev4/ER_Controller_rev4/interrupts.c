/*
 * interrupts.c - Interrupt routines for ER Controller
 *
 * Created: 11/13/2012 4:02:52 PM
 *  Author: dmh
 */

#include "interrupts.h"
volatile unsigned long timer0_millis = 0;
static unsigned char timer0_fract = 0;
volatile unsigned long door1_counter=0, door2_counter=0;

// Timer1A Compare Interrupt - Handles the independent operation
ISR ( TIMER1_COMPA_vect ) {
	
	unsigned long t;
	
	// Door 1
	if(dr1.isActive) {
		if(bit_is_clear(INPUT_PIN, DR1_BUTTON)) // Door1 Button is still pressed, reset the counter
			door1_counter = 0;
		else if( ++door1_counter > ((t=getTime(DR1_OUT))*10) ) // When the counter is >= time1, turn off door 1
		{
			activateDoor1(false);
			dr1.isActive = false;
			door1_counter = 0; // reset the counter for the next go round
		}
	}
	
	// Door 2
	if(dr2.isActive) {
		if(bit_is_clear(INPUT_PIN, DR2_BUTTON)) // Door2 Button is still pressed, reset the counter
			door2_counter=0;
		else if( ++door2_counter > ((t=getTime(DR2_OUT))*10) ) // When the counter is >= time2, turn off door 2
		{
			activateDoor2(false);
			dr2.isActive = false;
			door2_counter = 0; // reset the counter for the next go round
		}
	}
}

// Timer0 overflow interrupt - Increments the millis variable
ISR(TIMER0_OVF_vect) {
	unsigned long m = timer0_millis;
	unsigned char f = timer0_fract;
	
	m += MILLIS_INC;
	f += FRACT_INC;

	if (f >= FRACT_MAX) {
		f -= FRACT_MAX;
		m += 1;
	}
	timer0_fract = f;
	timer0_millis = m;
}

/*
Interrupt Handler For PCINT23:16 (PIND)
This routine changes the global variables and resynchronizes
the outputs to correspond with the changes	*/
ISR(PCINT2_vect) {
	// The set bits in 'reg' corresponds to the changed pin inputs
	uint8_t reg = (INPUT_PIN^inputs.inputReg);
	
	if(bit_get(reg, MODE_PIN)) // Operating Mode Changed
	{
		// Set the operating mode
		inputs.mode = (bit_get(INPUT_PIN, MODE_PIN)>0) ? DEPENDENT : INDEPENDENT;
		
		// Change the input register value
		bit_write(inputs.mode, inputs.inputReg, 1);
		
		// Turn off any active outputs for the new mode
		doorPinWrite(DR1_OUT,false);
		doorPinWrite(DR2_OUT,false);
		bit_clear(OUTPUT_PORT, bit(SIG1_OUT_PIN)|bit(SIG2_OUT_PIN));
		dr2.isToggled = false;
		dr1.isToggled = false;
		dr1.isActive = false;
		dr2.isActive = false;
		inputs.retracting = false;
		door_timer(false);
	}
	
	if(bit_get(reg, ACTIVE_MODE1_PIN)) // Door 1 Active Mode Changed
	{
		// Set the Door 1 active mode
		dr1.outputMode = (bit_get(INPUT_PIN, ACTIVE_MODE1_PIN)) ? ACTIVE_HIGH:ACTIVE_LOW;
		// Clear or set the input register
		(bit_get(INPUT_PIN, ACTIVE_MODE1_PIN)>0) ? sbi(inputs.inputReg, ACTIVE_MODE1_PIN) : cbi(inputs.inputReg, ACTIVE_MODE1_PIN);
		// Change door 1 output to correspond with the changes
		doorPinWrite(DR1_OUT, ((dr1.isActive||dr1.isToggled||inputs.retracting) ? true:false) );
	}

	if(bit_get(reg, ACTIVE_MODE2_PIN)) // Door 2 Active Mode Changed
	{
		// Set the Door 2 active mode
		dr2.outputMode = (bit_get(INPUT_PIN, ACTIVE_MODE2_PIN)) ? ACTIVE_HIGH:ACTIVE_LOW;
		// Clear or set the input register
		(bit_get(INPUT_PIN, ACTIVE_MODE2_PIN)) ? sbi(inputs.inputReg, ACTIVE_MODE2_PIN) : cbi(inputs.inputReg, ACTIVE_MODE2_PIN);
		// Change door 2 output to correspond with the changes
		doorPinWrite(DR2_OUT, ((dr2.isActive || dr2.isToggled||inputs.retracting) ? true:false) );
	}
	
	if(bit_get(reg, TOGGLE1_PIN)) // Door 1 Toggle Mode Changed
	{
		// Set the door 1 toggle value
		dr1.toggleMode = bit_get(INPUT_PIN, TOGGLE1_PIN) ? false:true;
		// Clear or set the input register
		dr1.toggleMode ? cbi(inputs.inputReg,TOGGLE1_PIN) : sbi(inputs.inputReg,TOGGLE1_PIN);
		//bit_write(!dr1.toggleMode, inputs.inputReg, bit(1)); // Change the input register value
		
		if( dr1.isToggled && dr1.toggleMode==false ) // Toggle mode changed to off and output is toggled!
		{
			doorPinWrite(DR1_OUT,false);
			cbi(OUTPUT_PORT,SIG1_OUT_PIN);
			dr1.isToggled = false;
			if(inputs.mode==DEPENDENT){
				doorPinWrite(DR2_OUT,false);
				cbi(OUTPUT_PORT,SIG2_OUT_PIN);
				dr2.isToggled = false;
			}
		}
	}

	if(bit_get(reg, TOGGLE2_PIN))// Door 2 Toggle Mode Changed
	{
		// Set the door 2 toggle value
		dr2.toggleMode = bit_get(INPUT_PIN, TOGGLE2_PIN) ? false:true;
		dr2.toggleMode ? cbi(inputs.inputReg,TOGGLE1_PIN) : sbi(inputs.inputReg,TOGGLE1_PIN);
		
		if( dr2.isToggled && dr2.toggleMode==false && inputs.mode == INDEPENDENT) //Toggle mode changed to off and output is toggled!
		{
			doorPinWrite(DR2_OUT,false);
			cbi(OUTPUT_PORT,SIG2_OUT_PIN);
			dr2.isToggled = false;
		}
		bit_write( !bit_get(dr2.toggleMode,0), inputs.inputReg, BIT(7)); // Change the input register value
	}
}