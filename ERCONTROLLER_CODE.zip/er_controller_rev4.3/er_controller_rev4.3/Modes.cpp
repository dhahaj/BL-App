/*
 * Modes.cpp
 *
 * Created: 1/24/2013 3:31:37 PM
 *  Author: Daniel
 */ 

#include "Modes.h"

 Modes::Modes( volatile uint8_t *PORT, volatile uint8_t *DDR, uint8_t INPUT_PIN )
{
	this->INPUT_PIN_PORT = PORT;
	this->_DDR = DDR;
	this->INPUT_PIN = INPUT_PIN;
	
	//*this->_DDR |= (1<<INPUT_PIN);
	
	cbi(*this->_DDR, this->INPUT_PIN);
	
	//this->value = getValue();
	
	//Modes::INPUT_MASK &= ~(1<<INPUT_PIN);
}

void Modes::setDD(uint8_t MASK) {
	*this->_DDR |= MASK;
}

 Modes::~Modes()
{
	
}

uint8_t Modes::getValue()
{
	uint8_t portValue = *this->INPUT_PIN_PORT & (1<<this->INPUT_PIN);
	if(portValue>0)
		return 1;
	else
		return 0;
}

uint8_t Modes::INPUT_MASK = 0;
