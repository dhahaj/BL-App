/*
 * Modes.h
 *
 * Created: 1/24/2013 3:31:46 PM
 *  Author: Daniel
 */ 


#ifndef MODES_H_
#define MODES_H_

#include "definitions.h"
#include "door.h"
#include <avr/io.h>

using namespace std;

#include <inttypes.h>

class Modes
{
	public:
	
		volatile uint8_t *INPUT_PIN_PORT, *_DDR;
		uint8_t INPUT_PIN;
		uint8_t value;
		static uint8_t INPUT_MASK;
		
		Modes(volatile uint8_t *, volatile uint8_t *, uint8_t);
		~Modes();
		void setDD(uint8_t MASK);
		uint8_t getValue();
		
	protected:
	
	private:
		
};



#endif /* MODES_H_ */