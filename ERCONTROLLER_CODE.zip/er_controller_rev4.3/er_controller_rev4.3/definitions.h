/*
 * definitions.h
 *
 * Created: 1/30/2013 2:37:45 PM
 *  Author: Daniel
 */ 


#ifndef DEFINITIONS_H_
#define DEFINITIONS_H_

#include <inttypes.h>

#define bit_set(p,m1) ((p) |= (m1))
#define bv(b) _BV(b);

#define cbi(sfr, bit) (_SFR_BYTE(sfr) &= ~_BV(bit))
#define sbi(sfr, bit) (_SFR_BYTE(sfr) |= _BV(bit))

#define bit_set(p,m1) ((p) |= (m1))
#define bit_clear(p,m1) ((p) &= ~(m1))
#define bit_write(c,p,m1) (c ? bit_set(p,m1) : bit_clear(p,m1))
#define BIT(x) (0x01 << (x))
#define bit(x) (0x01 << (x))
#define bit_get(p,m1) ((p) & (bit(m1)))

#ifndef boolean
typedef uint8_t boolean;
#endif
#ifndef byte
typedef uint8_t byte;
#endif

#ifndef cbi
#define cbi(sfr, bit) (_SFR_BYTE(sfr) &= ~_BV(bit))
#endif
#ifndef sbi
#define sbi(sfr, bit) (_SFR_BYTE(sfr) |= _BV(bit))
#endif
#ifndef true
#define true			(0==0)	// Boolean Types
#endif
#ifndef false
#define false			(0!=0)
#endif
#define nop __asm__("nop\n\t");
#define clockCyclesPerMicrosecond() ( F_CPU / 1000000L )
#define clockCyclesToMicroseconds(a) ( (a) / clockCyclesPerMicrosecond() )
#define MICROSECONDS_PER_TIMER0_OVERFLOW (clockCyclesToMicroseconds(64 * 256))
#define MILLIS_INC (MICROSECONDS_PER_TIMER0_OVERFLOW / 1000)
#define FRACT_INC ((MICROSECONDS_PER_TIMER0_OVERFLOW % 1000) >> 3)
#define FRACT_MAX (1000 >> 3)

#endif /* DEFINITIONS_H_ */