/*
 * door.cpp
 *
 * Created: 1/23/2013 5:46:38 PM
 *  Author: Daniel
 */ 

#include <avr/io.h>
#include "door.h"

uint8_t Door::PIN_MASK = 0x00;

// Constructors ///////////////////

Door::Door(volatile uint8_t *PORT, uint8_t PIN)
{
	this->_PORT = PORT;
	this->_DOOR_PIN = PIN;
	this->isActive = false;
	
	Door::PIN_MASK |= (1<<PIN);
}

Door::Door(volatile uint8_t *PORT, volatile uint8_t *DDR, uint8_t DOOR_PIN, uint8_t SIG_PIN)
{
	this->_PORT = PORT;
	this->_DDR = DDR;
	this->_DOOR_PIN = DOOR_PIN;
	this->_SIGNAL_PIN = SIG_PIN;
	this->isActive = false;
	
	Door::PIN_MASK |= (1<<DOOR_PIN) | (1<<SIG_PIN);
}

// Public Methods /////////////////

void Door::setDD(volatile uint8_t *DD)
{
	//Door::DDR = DD;
	//this->_DDR = DD;
	//*_DDR |= (1<<this->_DOOR_PIN);
}

void Door::start()
{
	*_DDR |= Door::PIN_MASK;
}

void Door::write(uint8_t mode)
{
	sbi(*_PORT, (this->_DOOR_PIN));
}

void Door::clear()
{
	cbi(*_PORT, this->_DOOR_PIN);
}

void Door::setActiveMode(uint8_t active_mode)
{
	this->ACTIVE_MODE = active_mode;
}

boolean Door::getActiveMode()
{
	return this->ACTIVE_MODE;
}

void Door::setOutputMode(uint8_t output_mode)
{
	this->OUTPUT_MODE = output_mode;
}

boolean Door::getOutputMode( void )
{
	return this->OUTPUT_MODE;
}

void Door::activateSignal() {
	sbi(*this->_PORT, this->_SIGNAL_PIN);
}

void Door::deactivateSignal() {
	cbi(*this->_PORT, this->_SIGNAL_PIN);
}

void Door::setSignalPin(uint8_t sig_pin)
{
	this->_SIGNAL_PIN = sig_pin;
}

Door& Door::operator++()
{
	this->activateSignal();
	return *this;
}

Door& Door::operator~()
{
	if(this->isActive)
		deactivateDoor();
	else
		activateDoor();
	return *this;
}

void Door::activateDoor()
{
	if(this->ACTIVE_MODE == ACTIVE_HIGH)
		sbi(*this->_PORT, this->_DOOR_PIN);
	else
		cbi(*this->_PORT, this->_DOOR_PIN);
	this->isActive = true;
}

void Door::deactivateDoor()
{
	if(this->ACTIVE_MODE == ACTIVE_HIGH)
		cbi(*this->_PORT, this->_DOOR_PIN);
	else
		sbi(*this->_PORT, this->_DOOR_PIN);
	this->isActive = false;
}

uint8_t Door::getDSPortValue()
{
	return this->DSPORT_VALUE;
}

void Door::setDSPortValue( uint8_t _value )
{
	this->DSPORT_VALUE = _value;
}










