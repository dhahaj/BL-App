/*
 * door.h
 *
 * Created: 1/23/2013 5:47:47 PM
 *  Author: Daniel
 */ 


// using namespace std;

#ifndef DOOR_H_
#define DOOR_H_

#include "definitions.h"
#include <inttypes.h>
#include <stdbool.h>
#include <util/twi.h>
//#include "new.h"

//#define cbi(sfr, bit) (_SFR_BYTE(sfr) &= ~_BV(bit))
//#define sbi(sfr, bit) (_SFR_BYTE(sfr) |= _BV(bit))

#define INDEPENDENT 0x00
#define DEPENDENT	0x01
#define ACTIVE_HIGH	0x11
#define ACTIVE_LOW	0x10

typedef uint8_t boolean;
#ifdef __cplusplus

class Door
{
	
	public:
		// Variables
		volatile uint8_t *_PORT, *_DDR;
		uint8_t _DOOR_PIN, _SIGNAL_PIN;
		uint8_t OUTPUT_MODE;
		static const uint8_t _PIN_MASK;
		static const unsigned long SIGNAL_DELAY;
		static const unsigned long DIFF_DELAY;
		boolean TOGGLE_MODE, ACTIVE_MODE, IS_TOGGLED, isActive;
		uint8_t DSPORT_VALUE;
		
		static volatile uint8_t *DDR;
		static uint8_t PIN_MASK;
		
		// Constructors
		Door(volatile uint8_t *PORT, uint8_t PIN);
		//Door(volatile uint8_t *PORT, volatile uint8_t *DDR, uint8_t PIN);
		Door(volatile uint8_t *PORT, volatile uint8_t *DDR, uint8_t DOOR_PIN, uint8_t SIG_PIN);
		
		// Methods
		void setDD(volatile uint8_t *);
		void setDDR(volatile uint8_t *);
		boolean getActiveMode();
		void setOutputMode(uint8_t mode);
		boolean getOutputMode();
		void write(uint8_t mode);
		void clear();
		void setActiveMode(uint8_t active_mode);
		static void setBitMask(uint8_t);
		void setSignalPin(uint8_t sig_pin);
		void activateDoor();
		void deactivateDoor();
		void activateSignal();
		void deactivateSignal();

		void start();
		
		Door& operator++();
		Door& operator~();
		
		void setDSPortValue(uint8_t);
		uint8_t getDSPortValue();
	
	protected:
	
	private:

	
};

#endif
#endif /* DOOR_H_ */