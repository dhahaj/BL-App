/*
 * er_controller_rev4.cpp
 *
 * Created: 1/23/2013 2:48:11 PM
 *  Author: Daniel
 */ 


#include <avr/io.h>
#include <avr/portpins.h>
#include <avr/interrupt.h>

#include "definitions.h"
#include "Modes.h"
#include "door.h"


Door door1(&PORTB, &DDRB, PB0, PB2);
Door door2(&PORTB, &DDRB, PB1, PB3);

Modes outputMode(&PIND, &DDRD, PIND0);
Modes toggleMode(&PIND, &DDRD, PIND1);

//volatile uint8_t * Door::DDR = &DDRB;
// Door door3(&PORTB, &DDRB, PB4);

#include "main.h"
#include "timers.h"
using namespace std;
#include "interrupts.h"
#include <util/delay.h>

//const uint8_t Door::_PIN_MASK = _BV(0) | _BV(1) | _BV(2) | _BV(3);
const unsigned long Door::DIFF_DELAY = 600UL;
const unsigned long Door::SIGNAL_DELAY = 600UL;

int main(void)
{
	uint8_t val = 0;
	
	DDRB = 0xff;
	
	//door1.ACTIVE_MODE = ACTIVE_HIGH;
	//door2.ACTIVE_MODE = ACTIVE_HIGH;
	//door1.start();
	
	//DDRB |= (1<<PB6)|(1<<PB4);
	// PORTB |= (1<<PB6);
	//cbi(PORTB, PB6);
	//sbi(PORTB, PB4);
    while(1)
    {
		
		PORTB |= (1<<toggleMode.getValue()) | outputMode.getValue() ;
		
		//PORTB |= outputMode.value;
        //door1.write(0);
		//door2.write(0);
		//~door1;
		//_delay_ms(1000);
		//~door2;
		//door1.clear();
		//door2.clear();
		//_delay_ms(1000);
		
    }
}

volatile unsigned long door1_counter=0, door2_counter=0;

// Timer1A Compare Interrupt - Handles the independent operation
ISR ( TIMER1_COMPA_vect ) {
	
	unsigned long t;
	
	// Door 1
	if(door1.isActive) {
		if(bit_is_clear(INPUT_PIN, DR1_BUTTON)) // Door1 Button is still pressed, reset the counter
		door1_counter = 0;
		else if( ++door1_counter > ((t=getTime(door1))*10) ) // When the counter is >= time1, turn off door 1
		{
			door1.activateDoor();
			//activateDoor1(false);
			//dr1.isActive = false;
			door1_counter = 0; // reset the counter for the next go round
		}
	}
	
	// Door 2
	if(door2.isActive) {
		if(bit_is_clear(INPUT_PIN, DR2_BUTTON)) // Door2 Button is still pressed, reset the counter
		door2_counter=0;
		else if( ++door2_counter > ((t=getTime(door2))*10) ) // When the counter is >= time2, turn off door 2
		{
			door2.activateDoor();
			//activateDoor2(false);
			//dr2.isActive = false;
			door2_counter = 0; // reset the counter for the next go round
		}
	}
}