/*
 * main.h
 *
 * Created: 1/23/2013 5:39:04 PM
 *  Author: Daniel
 */ 
//#include <avr/io.h>

#ifndef MAIN_H_
#define MAIN_H_



//#define bit_set(p,m1) ((p) |= (m1))
//#define bv(b) _BV(b);
//#define DEPENDENT		0x1		// Operating Mode Types
//#define INDEPENDENT		0x0
//#define ACTIVE_HIGH		0x1		// Output Mode Types
//#define ACTIVE_LOW		0x0

#define INPUT_PIN			PIND	// Input Port for Door 1 & Door 2
#define INPUT_PORT			PORTD	// Input Port for Door 1 & Door 2
#define INPUT_DDR			DDRD	// Data Direction for Input Ports
#define MODE_PIN			PIND0	// Mode selection pin
#define TOGGLE1_PIN			PIND4	// Toggle Mode pin for Door 1
#define TOGGLE2_PIN			PIND7	// Toggle Mode pin for Door 2
#define DR1_BUTTON			PIND2	// Door 1 Input Pin
#define DR2_BUTTON			PIND3	// Door 2 Input Pin
#define ACTIVE_MODE1_PIN	PIND1	// Active Mode Pin for Door 1
#define ACTIVE_MODE2_PIN	PIND5	// Active Mode Pin for Door 2
#define DS_PORT				PORTC	// Digital Switch Input Port
#define DS_PIN_PORT			PINC	// Digital Switch Input Pin Port
#define DS_DDR				DDRC	// Data Direction for DS_PORT
#define DS1_PIN				PC0		// DS1 Control Output Pin
#define DS2_PIN				PC1		// DS2 Control Output Pin
#define TESTMODE_PIN_PORT	PINB	// Port for testmode
#define TESTMODE_PIN		PINB6	// Pin for entering test mode
#define INPUT_MASK		(BIT(MODE_PIN) | BIT(TOGGLE1_PIN) | BIT(TOGGLE2_PIN) | BIT(DR1_BUTTON) | BIT(DR2_BUTTON) | BIT(ACTIVE_MODE1_PIN) | BIT(ACTIVE_MODE2_PIN))


//#include "door.h"
//#include "interrupts.h"

//#include <inttypes.h>

// using namespace std;
/*
#include <stdlib.h>
void * operator new(size_t size);
void operator delete(void * ptr);

void * operator new(size_t size)
{
	return malloc(size);
}

void operator delete(void * ptr)
{
	free(ptr);
}

__extension__ typedef int __guard __attribute__((mode (__DI__)));

extern "C" int __cxa_guard_acquire(__guard *);
extern "C" void __cxa_guard_release (__guard *);
extern "C" void __cxa_guard_abort (__guard *);

int __cxa_guard_acquire(__guard *g) {return !*(char *)(g);};
void __cxa_guard_release (__guard *g) {*(char *)g = 1;};
void __cxa_guard_abort (__guard *) {};

extern "C" void __cxa_pure_virtual(void);

void __cxa_pure_virtual(void) {};


*/

#endif /* MAIN_H_ */