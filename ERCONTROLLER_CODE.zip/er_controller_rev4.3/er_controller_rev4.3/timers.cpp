/*
 * timers.c
 *
 * Created: 11/14/2012 8:57:27 AM
 *  Author: dmh
 */ 

//#include "timers.h"
//#include "interrupts.h"
#include <util/atomic.h>
#include <avr/pgmspace.h>
#include "door.h"
#include "main.h"
//#include "door.h"
//#include "Doors.h"
//#include "door.h"

// Array holding the 4-bit timing selection values (in seconds)
const uint8_t PROGMEM timing_values_PGM[] = {
	1,	// 0
	2,	// 1
	5,	// 2
	10,	// 3
	15,	// 4
	20, // 5
	25,	// 6
	30,	// 7
	35,	// 8
	40, // 9
	45, // A
	50,	// B
	55,	// C
	60, // D
	90,	// E
	120,// F
};
#define getTimingValue(P) ( pgm_read_byte( timing_values_PGM + (P) ) )

// Returns the timing selection from the digital switches
unsigned long getTime( Door door )
{
	unsigned long t;
	uint8_t DSx_value;
	
	uint8_t pin = door._DOOR_PIN;
	
	DS_PORT = door.getDSPortValue();
	
	/*
	// Set the multiplexer address
	if(pin == door1._DOOR_PIN) {
		sbi(DS_PORT, DS1_PIN);
		cbi(DS_PORT, DS2_PIN);
	} else {
		sbi(DS_PORT, DS2_PIN);
		cbi(DS_PORT, DS1_PIN);
	}
	*/
	
	DSx_value = (DS_PIN_PORT & 0x3c)>>2;
	t = getTimingValue(DSx_value);
	// (pin == door1._DOOR_PIN) ? cbi(DS_PORT, DS1_PIN) : cbi(DS_PORT, DS2_PIN);
	return t;
}



