/*
 * myStuff.h
 *
 * Created: 7/25/2012 2:07:38 PM
 *  Author: dmh
 */ 

#ifndef TIMERS_H_
#define TIMERS_H_

#include <avr/interrupt.h>
#include "main.h"
#include "door.h"

//#ifndef boolean
//typedef uint8_t boolean;
//#endif
//#ifndef byte
//typedef uint8_t byte;
//#endif
//
//#ifndef cbi
//#define cbi(sfr, bit) (_SFR_BYTE(sfr) &= ~_BV(bit))
//#endif
//#ifndef sbi
//#define sbi(sfr, bit) (_SFR_BYTE(sfr) |= _BV(bit))
//#endif
//#ifndef true
//#define true			(0==0)	// Boolean Types
//#endif
//#ifndef false
//#define false			(0!=0)
//#endif
//#define nop __asm__("nop\n\t");
//#define clockCyclesPerMicrosecond() ( F_CPU / 1000000L )
//#define clockCyclesToMicroseconds(a) ( (a) / clockCyclesPerMicrosecond() )
//#define MICROSECONDS_PER_TIMER0_OVERFLOW (clockCyclesToMicroseconds(64 * 256))
//#define MILLIS_INC (MICROSECONDS_PER_TIMER0_OVERFLOW / 1000)
//#define FRACT_INC ((MICROSECONDS_PER_TIMER0_OVERFLOW % 1000) >> 3)
//#define FRACT_MAX (1000 >> 3)
//#define bit_set(p,m1) ((p) |= (m1))
//#define bit_clear(p,m1) ((p) &= ~(m1))
//#define bit_write(c,p,m1) (c ? bit_set(p,m1) : bit_clear(p,m1))
//#define BIT(x) (0x01 << (x))
//#define bit(x) (0x01 << (x))
//#define bit_get(p,m1) ((p) & (bit(m1)))

// long map(long x, long in_min, long in_max, long out_min, long out_max)
// {
// 	return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
// }





#endif /* TIMERS_H_ */