/*
 * timers.c
 *
 * Created: 11/14/2012 8:57:27 AM
 *  Author: dmh
 */ 

#include "timers.h"
#include "interrupts.h"
#include <util/atomic.h>

// Array holding the 4-bit timing selection values (in seconds)
const uint8_t PROGMEM timing_values_PGM[] = {
	1,	// 0
	2,	// 1
	5,	// 2
	10,	// 3
	15,	// 4
	20, // 5
	25,	// 6
	30,	// 7
	35,	// 8
	40, // 9
	45, // A
	50,	// B
	55,	// C
	60, // D
	90,	// E
	120,// F
};
#define getTimingValue(P) ( pgm_read_byte( timing_values_PGM + (P) ) )

// Returns the timing selection from the digital switches
unsigned long getTime(uint8_t _doorPin) {
	unsigned long t;
	uint8_t DSx_value;
	// Set the multiplexer address
	if(_doorPin==DR1_OUT) {
		sbi(DS_PORT, DS1_PIN);
		cbi(DS_PORT, DS2_PIN);
	} else {
		sbi(DS_PORT, DS2_PIN);
		cbi(DS_PORT, DS1_PIN);
	}
	DSx_value = (DS_PIN_PORT & 0x3c)>>2;
	t = getTimingValue(DSx_value);
	(_doorPin==DR1_OUT) ? cbi(DS_PORT, DS1_PIN) : cbi(DS_PORT, DS2_PIN);
	return t;
}

//  Returns the time or resets the timer
unsigned long door_timer(boolean reset) {
	if(reset) {
		// Reset the Door 1 timer
		ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
			timer0_millis = 0;
			timer0_fract = 0;
		}
		return 0;
	}
	// Else, return the time since last reset
	unsigned long t;
	ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
		t = timer0_millis;
	}
	return t;
}

