/*
 * er_controller_rev4.cpp
 *
 * Created: 9/10/2013 2:42:20 PM
 *  Author: Daniel
 */ 


// #include <avr/io.h>

