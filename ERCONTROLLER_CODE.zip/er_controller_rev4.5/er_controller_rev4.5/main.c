/*
* main.cpp
*
* Rev 4.4:
*	1) Moved Signal1 from PB2 to PA0
*	2) Moved Signal2 from PB3 to PA1
*	3) Fixed toggling during signal delay
*
* Rev 4.5:
*	1) Modified Options port pins to match rev B board
*
* Created: 9/10/2013 11:51:59 AM
*  Author: Daniel
*/

// Includes:
#include <avr/io.h>
#include <util/delay.h>
#include <avr/wdt.h>
#include <util/atomic.h>
#include <avr/interrupt.h>
#include <avr/portpins.h>
#include <avr/sfr_defs.h>
#include "timers.h"
#include "interrupts.h"

// Initialize Door fields with the default configuration
Door dr1 = {false, false, ACTIVE_HIGH, DR1_OUT};
Door dr2 = {false, false, ACTIVE_HIGH, DR2_OUT};

Inputs inputs = {DEPENDENT, 0x00, false};

int main(void) {

	// Setup:
	DR_DDR |= ( bit(DR1_OUT) | bit(DR2_OUT)); // Initialize door output port
	
	SIG_DDR |= ( bit(SIG1_OUT_PIN) | bit(SIG2_OUT_PIN) ); // Initialize signal output port
	
	DS_DDR |= ( BIT(DS1_PIN) | BIT(DS2_PIN) );	// PC0 & PC1 set as outputs for DS switches
	
	wdt_reset();
	wdt_enable(WDTO_2S); // Enable Watchdog Timer @ 2 second time-out
	
 	sbi(PCICR,PCIE2); // Enable Pin Change Interrupt 2	
 	PCMSK2 = BIT(PCINT16)|BIT(PCINT17)|BIT(PCINT20)|BIT(PCINT23)|BIT(PCINT22); // Enable Interrupts on input pins
	
	TCCR0A |= BIT(CS01)|BIT(CS00); // Initialize timer0 with a prescaler of 64
	sbi(TIMSK0, TOIE0); 	// enable timer 0 overflow interrupt
	
	TCCR1B |= (1 << WGM12 ); // Configure timer 1 for CTC mode
	TIMSK1 |= BIT(OCIE1A); // Enable Output Compare Interrupt Channel A

	sei(); // Turn on interrupts

 	OCR1A = 1562; // Set CTC compare value to 0.2Hz at 1 MHz AVR clock , with a prescaler of 64
	TCCR1B |= ((1 << CS10 ) | (1 << CS11 )); // Start timer at Fcpu /64
	
	setInputs();
	
	// Set the outputs in the case of Active LOW settings
// 	doorPinWrite(dr1, doorIsToggled(dr1));
// 	doorPinWrite(dr2, doorIsToggled(dr2));
	doorPinWrite(dr1, ((dr1.isActive || doorIsToggled(dr1) || inputs.retracting) ? true:false) );
	doorPinWrite(dr2, ((dr2.isActive || doorIsToggled(dr2) || inputs.retracting) ? true:false) );	
	
	boolean dr1BtnReleased=true, dr2BtnReleased=true;
	
	// MAIN LOOP:
	for(;;)	{
		
	   /*********************
		*	Dependent Mode	*
		*********************/
		if(inputs.mode==DEPENDENT) {
			if(  button_is_pressed(&INPUT_PIN, DR2_BUTTON) || button_is_pressed(&INPUT_PIN, DR1_BUTTON) )
				dependentRetract();
		}
		
		
	   /*************************
		*	Independent Mode	*
		*************************/
		else if(inputs.mode==INDEPENDENT) {
		
			//	Poll the Door 1 button
			if( button_is_pressed(&INPUT_PIN, DR1_BUTTON) ) {
				// Toggle if in toggle mode && button has been released
				if( dr1.toggleMode && dr1BtnReleased ) {
					dr1BtnReleased=false; // Change the previous button state off
					activateDoor1(!doorIsToggled(dr1));
				}
				
				// Activate door if not in toggle mode
				else if(!dr1.toggleMode) {
					if(!dr1.isActive){
						dr1.isActive = true;
						activateDoor1(true);
					}				
				}
			} else dr1BtnReleased=true;
			
			
			//	Poll the Door 2 button
			if( button_is_pressed(&INPUT_PIN, DR2_BUTTON) ) {
				// Toggle if in toggle mode && button has been released
				if(dr2.toggleMode && dr2BtnReleased) {
					dr2BtnReleased=false; // Change the previous button state off
					activateDoor2(!doorIsToggled(dr2));
				}
				
				// Activate door if not in toggle mode
				else if(!dr2.toggleMode) {
					if(!dr2.isActive){
						dr2.isActive = true;
						activateDoor2(true);
					}					
				}
			} else dr2BtnReleased=true;
		}
		
		//	Reprocess inputs if any have changed
		if( inputs.inputReg != (INPUT_PIN & INPUT_MASK) )
			setInputs();
			
		wdt_reset(); // Reset the watchdog timer
	}
}

// Get the configuration setup from the DIP switch
void setInputs(void) {
		inputs.inputReg = INPUT_PIN & INPUT_MASK;
		inputs.mode = bit_is_set(inputs.inputReg, MODE_PIN) ? DEPENDENT : INDEPENDENT;
		dr1.toggleMode = bit_is_set(inputs.inputReg, TOGGLE1_PIN) ? false : true;
		// dr1.outputMode = (bit_get(INPUT_PIN, ACTIVE_MODE1_PIN)) ? ACTIVE_HIGH:ACTIVE_LOW;
		dr1.outputMode = bit_is_set(inputs.inputReg, ACTIVE_MODE1_PIN) ? ACTIVE_HIGH : ACTIVE_LOW;
		dr2.toggleMode = bit_is_set(inputs.inputReg,TOGGLE2_PIN) ? false : true;
		dr2.outputMode = (bit_get(INPUT_PIN, ACTIVE_MODE2_PIN)) ? ACTIVE_HIGH:ACTIVE_LOW;
}

void doorPinWrite(Door door, boolean high) {
	
	if(high){
		if(doorIsToggled(door)){
			bit_write(1, DR_PORT, bit(door.pin));	
		} else {
			bit_write(0, DR_PORT, bit(door.pin));
		}		
	} else {
		
		if(doorIsToggled(door)){
			bit_write(0, DR_PORT, bit(door.pin));	
		} else {
			bit_write(1, DR_PORT, bit(door.pin));
		}
		
		//bit_write( !door.outputMode, DR_PORT, bit(door.pin));
	}
	//bit_write( high & door.outputMode, DR_PORT, bit(door.pin));
}

// method which handles the dependent operation
void dependentRetract(void) {
	
	//	In toggle mode?
	if(dr1.toggleMode==true) {
		// if(dr1.isToggled==true) // Outputs currently toggled, so toggle them off
		if(doorIsToggled(dr1)) // Outputs currently toggled, so toggle them off
		{
			doorPinWrite(dr1, false);
			doorPinWrite(dr2, false);
			
			cbi(SIG_PORT, SIG1_OUT_PIN);	// Turn off door signal outputs
			cbi(SIG_PORT, SIG2_OUT_PIN);
			
		} 	else { // Outputs not toggled, so toggle them now 
				ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
					doorPinWrite(dr1, true);
					_delay_ms(DIFF_DELAY); // Differential Delay
					wdt_reset(); // Reset the watchdog timer	
					doorPinWrite(dr2, true);
					_delay_ms(SIG_DELAY);	// Door Signal Delay
					
					sbi(SIG_PORT, SIG1_OUT_PIN);	// Turn on door signal outputs
					sbi(SIG_PORT, SIG2_OUT_PIN);
				}
			}
		while( bit_is_clear(INPUT_PIN, DR1_BUTTON) || bit_is_clear(INPUT_PIN, DR2_BUTTON) ) // Maintain while buttons are held
			wdt_reset();
	} else { // Not in toggle mode
		ATOMIC_BLOCK(ATOMIC_RESTORESTATE){
			inputs.retracting = true;
			doorPinWrite(dr1,true); // Door 1 Active
			_delay_ms(DIFF_DELAY); // Differential Delay
			doorPinWrite(dr2,true); // Door 2 Active
			_delay_ms(SIG_DELAY);	// Door Signal Delay
			
			sbi(SIG_PORT, SIG1_OUT_PIN);	// Turn on door signal outputs
			sbi(SIG_PORT, SIG2_OUT_PIN);
		}
		door_timer(true); // Reset the Door timer
		unsigned long t;
		while( door_timer(false) <= ((t=getTime(DR1_OUT))*1000) ) // Hold Time Delay, value set from DS1
		{
			wdt_reset(); // Reset the watchdog timer
			if( dr1.toggleMode==true )
				break;
			if( bit_is_clear(INPUT_PIN, DR1_BUTTON) || bit_is_clear(INPUT_PIN, DR2_BUTTON) )	// Maintain active outputs when button is held
				door_timer(true); // reset the timer 
			if(inputs.mode==INDEPENDENT || dr1.toggleMode==true) // If output or toggle mode changed, break loop
				break;
		}
		doorPinWrite(dr1,false); // Door outputs off
		doorPinWrite(dr2,false);
		
		cbi(SIG_PORT, SIG1_OUT_PIN);	// Turn off door signal outputs
		cbi(SIG_PORT, SIG2_OUT_PIN);
		
		inputs.retracting = false;
	}
}

// method for door 1 independent operation
void activateDoor1(boolean activate){
	if(activate==false){
		doorPinWrite(dr1,false);
		cbi(SIG_PORT, SIG1_OUT_PIN); // Door 1 Signal OFF
	} else {
			doorPinWrite(dr1, true);
			
			boolean dr2BtnPressed = false;
			
			// reset the timer
			door_timer(true);
			
			// Monitor the second input while waiting for
			// the signal delay to expire
			while( (door_timer(false)) <= SIG_DELAY) {
				if(bit_is_clear(INPUT_PIN, DR2_BUTTON))
					dr2BtnPressed = true;
			}
			
			// Activate relay 1
			sbi(SIG_PORT, SIG1_OUT_PIN);
			
			// See if the button was pressed during the delay time
			if(dr2BtnPressed) {
				if(dr2.toggleMode){
					// activateDoor2(dr2.isToggled = !dr2.isToggled);
					activateDoor2(!doorIsToggled(dr2));
				} else {
					activateDoor2(dr2.isActive = !dr2.isActive);					
				}
			}
	}
	wdt_reset(); // Reset the watchdog timer
}

//method for door 2 independent operation
void activateDoor2(boolean activate){
	if(activate==false){
		doorPinWrite(dr2, false);
		cbi(SIG_PORT, SIG2_OUT_PIN);
	} else {
		
		// Activate door 2	
		doorPinWrite(dr2, true);

		boolean dr1BtnPressed = false;
		
		// reset the timer
		door_timer(true);
		
		// Monitor input 1 while waiting for the 
		// signal delay to expire
		while((door_timer(false)) <= SIG_DELAY) {
			if(bit_is_clear(INPUT_PIN, DR1_BUTTON))
				dr1BtnPressed = true;
		}
			
		// Activate relay 2
		sbi(SIG_PORT, SIG2_OUT_PIN);
			
		//  See if the button was pressed during the delay time
		if(dr1BtnPressed) {
			if(dr1.toggleMode){
				activateDoor1(!doorIsToggled(dr1));
			} else {				
				activateDoor1(dr1.isActive = !dr1.isActive);
			}				
		}
	}
	wdt_reset(); // Reset the watchdog timer
}

// method for debouncing the inputs
boolean button_is_pressed(uint8_t *PIN, uint8_t BUTTON_BIT) {
	// the button is pressed when BUTTON_BIT is clear
	if ( bit_is_clear(*PIN, BUTTON_BIT) )	{
		_delay_ms(DEBOUNCE_TIME);
		if (bit_is_clear(*PIN, BUTTON_BIT) ) return true;
	}
	return false;
}

boolean doorIsToggled(Door dr) {
	// uint8_t portValue = 0x01 & (OUTPUT_PIN_PORT>>dr.pin); // Read the output port
	uint8_t portValue = 0x01 & (DR_PIN_PORT>>dr.pin); // Read the output port
	return ( portValue==dr.outputMode ) ;
}


