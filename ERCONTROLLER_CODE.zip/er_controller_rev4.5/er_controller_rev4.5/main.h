/*
 * main.h
 *
 * Created: 1/23/2013 11:54:48 AM
 *  Author: Daniel
 */ 


#ifndef MAIN_H_
#define MAIN_H_


#include <stdint.h>
#include <avr/pgmspace.h>

						/*
OUTPUT DEFINITIONS:		*/
#define DR_PORT			PORTB
#define DR_PIN_PORT		PINB
#define DR_DDR			DDRB
#define DR1_OUT			PB0		// Door 1 output pin
#define DR2_OUT			PB1		// Door 2 output pin

#define SIG_PORT		PORTA
#define SIG_PIN_PORT	PINA
#define SIG_DDR			DDRA
#define SIG_PORT		PORTA	// Door signal relay output port
#define SIG_DDR			DDRA
#define SIG1_OUT_PIN	PA0		// Signal 1 output pin
#define SIG2_OUT_PIN	PA1		// Signal 2 output pin

						/*
INPUT DEFINITIONS:		*/
#define INPUT_PIN			PIND	// Input Port for Door 1 & Door 2
#define INPUT_PORT			PORTD	// Input Port for Door 1 & Door 2
#define INPUT_DDR			DDRD	// Data Direction for Input Ports
#define MODE_PIN			PIND7	// Mode selection pin
#define TOGGLE1_PIN			PIND4	// Toggle Mode pin for Door 1
#define TOGGLE2_PIN			PIND0	// Toggle Mode pin for Door 2
#define DR1_BUTTON			PIND2	// Door 1 Input Pin
#define DR2_BUTTON			PIND3	// Door 2 Input Pin
#define ACTIVE_MODE1_PIN	PIND6	// Active Mode Pin for Door 1
#define ACTIVE_MODE2_PIN	PIND1	// Active Mode Pin for Door 2
#define DS_PORT				PORTC	// Digital Switch Input Port
#define DS_PIN_PORT			PINC	// Digital Switch Input Pin Port
#define DS_DDR				DDRC	// Data Direction for DS_PORT
#define DS1_PIN				PC0		// DS1 Control Output Pin
#define DS2_PIN				PC1		// DS2 Control Output Pin
#define TESTMODE_PIN_PORT	PINB	// Port for testmode
#define TESTMODE_PIN		PINB6	// Pin for entering test mode
#define INPUT_MASK		(BIT(MODE_PIN) | BIT(TOGGLE1_PIN) | BIT(TOGGLE2_PIN) | BIT(DR1_BUTTON) | BIT(DR2_BUTTON) | BIT(ACTIVE_MODE1_PIN) | BIT(ACTIVE_MODE2_PIN))

#define DIFF_DELAY		500UL	// Differential Delay Time between door retractions(ms)
#define SIG_DELAY		500UL	// Signal Delay Time before activating door signals(ms)
#define DEPENDENT		0x1		// Operating Mode Types
#define INDEPENDENT		0x0
#define ACTIVE_HIGH		0x1		// Output Mode Types
#define ACTIVE_LOW		0x0
#define DEBOUNCE_TIME	75		// Switch Debounce Time

#ifndef boolean
typedef uint8_t boolean;
#endif
#ifndef byte
typedef uint8_t byte;
#endif
#ifndef true
#define true			(0==0)	// Boolean Types
#endif
#ifndef false
#define false			(0!=0)
#endif
#ifndef cbi
#define cbi(sfr, bit) (_SFR_BYTE(sfr) &= ~_BV(bit))
#endif
#ifndef sbi
#define sbi(sfr, bit) (_SFR_BYTE(sfr) |= _BV(bit))
#endif

typedef struct {
	volatile boolean toggleMode, isActive;
	volatile uint8_t outputMode;
	uint8_t pin;
} Door;

Door dr1;
Door dr2;

typedef struct {
	volatile boolean mode;
	volatile uint8_t inputReg;
	boolean retracting;
	//const uint8_t inputPinMask;
} Inputs;

Inputs inputs;

unsigned long door_timer(boolean reset);
unsigned long getTime(uint8_t _doorPin);
void dependentRetract(void);
void activateDoor1(boolean activate);
void activateDoor2(boolean activate);
void setInputs(void);
boolean button_is_pressed(uint8_t *PIN, uint8_t BUTTON_BIT);
boolean doorIsToggled(Door dr);

#endif /* MAIN_H_ */